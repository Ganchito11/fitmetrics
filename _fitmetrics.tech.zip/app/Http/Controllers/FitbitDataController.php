<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Artisan;
use App\Models\Token;
use App\Models\DatosGeneralesFitbit;
use App\Models\UserFitbitInfo;
use App\Models\User;
use App\Models\FitbitActivityMonthlyData;
use App\Models\SleepSession;
use Carbon\Carbon;
use DateTime;


class FitbitDataController extends Controller
{
    private function getEncodedIds()
    {
        $user = auth()->user(); // Obtener el usuario de sesión
        $tokens = Token::where('appUser', $user->name)->get(); // Obtener los tokens del usuario de sesión
        return $tokens->pluck('userID'); // Obtener los encoded_id de los tokens
    }

    private function getAge($dateOfBirth)
    {
        return Carbon::parse($dateOfBirth)->age;
    }

    public function showUserList()
    {
        $encodedIds = $this->getEncodedIds();

        $userFitbitInfo = UserFitbitInfo::whereIn('encoded_id', $encodedIds)->get(); // Obtener los datos generales de Fitbit relacionados con los tokens

        return view('fitbit.fitbit_users', ['UserFitbitInfo' => $userFitbitInfo, 'encodedIds' => $encodedIds]);
    }

    public function showUserInfo(Request $request, $encoded_id)
    {
        // Obtener el token seleccionado de la URL
        $selectedUser = $encoded_id;

        // Verificar si se seleccionó un token
        if (!$selectedUser) {
            // Manejar el caso cuando no se selecciona un token
            return response()->json(['error' => 'No se ha seleccionado un token'], 400);
        }

        $encodedIds = $this->getEncodedIds();

        // Obtener todos los usuarios
        $userFitbitInfo = UserFitbitInfo::whereIn('encoded_id', $encodedIds)->get();

        // Verificar si se encontraron registros
        if ($userFitbitInfo->isEmpty()) {
            // Manejar el caso cuando no se encuentra información del usuario
            return response()->json(['error' => 'No se encontró información del usuario'], 404);
        }

        $selectedUserFitbitInfo = $userFitbitInfo->where('encoded_id', $selectedUser)->first(); // Obtener el usuario seleccionado

        return view('fitbit.fitbit_users', [
            'UserFitbitInfo' => $userFitbitInfo,
            'selectedUser' => $selectedUser,
            'encodedIds' => $encodedIds,
            'age' => $this->getAge($selectedUserFitbitInfo->date_of_birth), // Agregar la edad a la vista
        ]);
    }

    public function showFitbitDashboard()
    {
        $encodedIds = $this->getEncodedIds();

        // Obtener los datos de la tabla datos_generales_fitbit relacionados con los tokens
        $datosGenerales = DatosGeneralesFitbit::whereIn('encoded_id', $encodedIds)->get();

        // Pasar los datos a la vista del Fitbit Dashboard
        return view('fitbit.fitbit-dashboard', ['datosGenerales' => $datosGenerales]);
    }
    
    public function showCalories($encoded_id = null)
    {
        $encodedIds = $this->getEncodedIds();
        $userFitbitInfo = UserFitbitInfo::whereIn('encoded_id', $encodedIds)->get();
    
        if ($userFitbitInfo->isEmpty()) {
            // Si no hay datos, muestra un mensaje en la pantalla y detén la ejecución de la función
            session()->flash('alert-warning', 'Aún no hay datos existentes. Por favor, sincronice con un usuario Fitbit');
            return back();
        }
    
        if (!$encoded_id) {
            $encoded_id = $userFitbitInfo->first()->encoded_id;
        }
    
        $caloriesData = FitbitActivityMonthlyData::where('encoded_id', $encoded_id)
            ->select('date', 'calories_out')
            ->get();
    
        // Pasar los datos a la vista
        return view('fitbit.calories', ['caloriesData' => $caloriesData, 'UserFitbitInfo' => $userFitbitInfo, 'selectedUser' => $encoded_id]);
    }
    

    public function showSteps($encoded_id = null)
    {
        $encodedIds = $this->getEncodedIds();
        $userFitbitInfo = UserFitbitInfo::whereIn('encoded_id', $encodedIds)->get();
    
        if ($userFitbitInfo->isEmpty()) {
            // Si no hay datos, muestra un mensaje en la pantalla y detén la ejecución de la función
            session()->flash('alert-warning', 'Aún no hay datos existentes. Por favor, sincronice con un usuario Fitbit');
            return back();
        }
    
        if (!$encoded_id && $userFitbitInfo->isNotEmpty()) {
            $encoded_id = $userFitbitInfo->first()->encoded_id;
        }
    
        $stepsData = FitbitActivityMonthlyData::where('encoded_id', $encoded_id)
            ->select('date', 'steps')
            ->get();
    
        // Pasar los datos a la vista
        return view('fitbit.steps', ['stepsData' => $stepsData, 'UserFitbitInfo' => $userFitbitInfo, 'selectedUser' => $encoded_id]);
    }
    
    public function showHeartRateZones($encoded_id = null)
    {
        $encodedIds = $this->getEncodedIds();
        $userFitbitInfo = UserFitbitInfo::whereIn('encoded_id', $encodedIds)->get();
    
        if ($userFitbitInfo->isEmpty()) {
            // Si no hay datos, muestra un mensaje en la pantalla y detén la ejecución de la función
            session()->flash('alert-warning', 'Aún no hay datos existentes. Por favor, sincronice con un usuario Fitbit');
            return back();
        }
    
        if (!$encoded_id && $userFitbitInfo->isNotEmpty()) {
            $encoded_id = $userFitbitInfo->first()->encoded_id;
        }
    
        $heartRateZonesData = FitbitActivityMonthlyData::where('encoded_id', $encoded_id)
            ->select('date', 'heart_rate_zones')
            ->get();
    
        // Verificar si los datos son nulos y asignar un valor predeterminado si es necesario
        foreach ($heartRateZonesData as $data) {
            if ($data->heart_rate_zones === null) {
                $data->heart_rate_zones = [0, 0, 0, 0]; // Asignar un arreglo con cuatro ceros como valor predeterminado
            }
        }
    
        // Pasar los datos a la vista
        return view('fitbit.heart_zones', ['heartRateZonesData' => $heartRateZonesData, 'UserFitbitInfo' => $userFitbitInfo, 'selectedUser' => $encoded_id]);
    }

    public function showSleep(Request $request)
    {
        $encodedIds = $this->getEncodedIds();
        $userFitbitInfo = SleepSession::whereIn('user_id', $encodedIds)->distinct('user_id')->get(['user_id']);
    
        if ($userFitbitInfo->isEmpty()) {
            session()->flash('alert-warning', 'Aún no hay datos existentes. Por favor, sincronice con un usuario Fitbit');
            return back();
        }
    
        $selectedUser = $request->input('selectedUser');
        $selectedStartTime = $request->input('startTime');
    
        $sleepSessions = SleepSession::where('user_id', $selectedUser)
            ->where('start_time', $selectedStartTime)
            ->get();
    
        $startTimes = SleepSession::where('user_id', $selectedUser)->pluck('start_time')->unique();
    
        // Pasar los datos a la vista
        return view('fitbit.sleep', [
            'userFitbitInfo' => $userFitbitInfo,
            'sleepSessions' => $sleepSessions,
            'selectedUser' => $selectedUser,
            'selectedStartTime' => $selectedStartTime,
            'startTimes' => $startTimes
        ]);
    }
    
  

    public function generateData()
    {
        exec('sh /home/u401132006/domains/fitmetrics.tech/batch/fitbit_carga_datos_mensual.sh');

        // Redirigir al dashboard o mostrar un mensaje de éxito
        return redirect()->route('fitbit-dashboard')->with('success', 'Los datos de los últimos 31 días han sido generados exitosamente.');
    }
}
