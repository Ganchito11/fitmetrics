<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use GuzzleHttp\Client;
use Carbon\Carbon;
use App\Models\Token;

class FitbitSyncController extends Controller
{
    // Declarar propiedades de clase
    private $OAuthTwoClientID;
    private $clientSecret;
    private $tokenURL;
    private $authorizationHeader;
    private $contentType;

    public function __construct()
    {
        // Inicializar propiedades de clase en el constructor
        $this->OAuthTwoClientID = "238NMS";
        $this->clientSecret = "d57ecbed856d07c3ae0348df9f2d7542";
        $this->tokenURL = "https://api.fitbit.com/oauth2/token";
        $this->authorizationHeader = 'Basic ' . base64_encode($this->OAuthTwoClientID . ':' . $this->clientSecret);
        $this->contentType = 'application/x-www-form-urlencoded';
    }

    public function redirectToSync()
    {
        // Obtén el usuario autenticado actualmente
        $user = Auth::user();
        
        // Obtén el token del usuario actual
        $tokens = Token::where('appUser', $user->name)->get();
        
        // Redirigir a la vista fitbit_sync.blade.php y pasar el objeto $user y $token
        return view('fitbit_sync.fitbit_sync')->with('user', $user)->with('tokens', $tokens);
    }

    public function sync(Request $request)
    {

        // Generar el código y el desafío para la autorización
        $codeVerifier = self::generateRandomCode(128);
        $codeChallenge = self::generateCodeChallenge($codeVerifier);

        // Guardar el codeVerifier en la sesión para ser utilizado más tarde
        $request->session()->put('codeVerifier', $codeVerifier);

        $authorizeUrl = "https://www.fitbit.com/oauth2/authorize";
        $responseType = "code";
        $clientID = $this->OAuthTwoClientID;
        $scope = "activity cardio_fitness electrocardiogram heartrate location nutrition oxygen_saturation profile respiratory_rate settings sleep social temperature weight";
        $codeChallenge = urlencode($codeChallenge);
        $codeChallengeMethod = "S256";
        $redirectURI = urlencode("https://fitmetrics.tech/fitbit/oauth2-callback");

        $url = $authorizeUrl . "?" . "response_type=" . $responseType . "&client_id=" . $clientID . "&scope=" . $scope . "&code_challenge=" . $codeChallenge . "&code_challenge_method=" . $codeChallengeMethod . "&redirect_uri=" . $redirectURI;

        // Redirigir a la URL generada en una nueva pestaña
        return redirect()->away($url);
    }

    public function handleAuthorizationCallback(Request $request)
    {
        // Obtener el código de autorización de los parámetros de la URL
        $authorizationCode = $request->query('code');
    
        // Rescatar el codeVerifier de la sesión
        $codeVerifier = $request->session()->get('codeVerifier');
        
        try {
            $data = [
                'client_id' => $this->OAuthTwoClientID,
                'grant_type' => 'authorization_code',
                'redirect_uri' => 'https://fitmetrics.tech/fitbit/oauth2-callback',
                'code' => $authorizationCode,
                'code_verifier' => $codeVerifier
            ];
    
            $client = new Client();
    
            $response = $client->request('POST', $this->tokenURL, [
                'headers' => [
                    'Authorization' => $this->authorizationHeader,
                    'Content-Type' => $this->contentType,
                ],
                'form_params' => $data,
            ]);
    
            $responseData = json_decode($response->getBody(), true);
    
            // Obtener el accessToken, refreshToken y userID de la respuesta
            $accessToken = $responseData['access_token'];
            $refreshToken = $responseData['refresh_token'];
            $userID = $responseData['user_id'];

            if (Token::where('userID', $userID)->exists()) {
                $flag = False;
            } else {
                $flag = True;
            }

    
            // Obtener el nombre del usuario actualmente autenticado
            $user = Auth::user();
            $nombreUsuario = $user->name;
    
            // Obtener la fecha y hora actual
            $now = Carbon::now();
    
            // Crear un nuevo objeto Token y asignar los valores
            $tokenData = [
                'accessToken' => $accessToken,
                'refreshToken' => $refreshToken,
                'userID' => $userID,
                'appUser' => $nombreUsuario,
                'lastUpdate' => $now,
            ];
    
            Token::updateOrInsert(['userID' => $userID, 'appUser' => $nombreUsuario], $tokenData);
    
            if ($flag) {
                return view('fitbit_sync.sync_in_progress');
            } else {
                return view('fitbit_sync.sync_exist');
            }
            
    
        } catch (\Illuminate\Http\Client\RequestException $e) {
            // Registrar el error en un archivo de registro
            Log::error('Error en la solicitud POST a Fitbit: ' . $e->getMessage());
    
            // Enviar una notificación al administrador del sistema
            // mail(...);
    
            // Retornar una respuesta de error al usuario
            return response()->json(['error' => 'Se produjo un error en la sincronización. Por favor, inténtelo de nuevo más tarde.'], 500);
        }
    }
    

    public static function generateRandomCode($length)
    {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_-';
        $code = '';
        $charactersLength = strlen($characters);

        for ($i = 0; $i < $length; $i++) {
            $code .= $characters[rand(0, $charactersLength - 1)];
        }

        return $code;
    }

    public static function generateCodeChallenge($codeVerifier)
    {
        $codeChallenge = self::base64UrlEncode(hash('sha256', $codeVerifier, true));
        return $codeChallenge;
    }

    public static function base64UrlEncode($data)
    {
        $base64 = base64_encode($data);
        $base64Url = strtr($base64, '+/', '-_');
        $base64Url = rtrim($base64Url, '=');
        return $base64Url;
    }
}
