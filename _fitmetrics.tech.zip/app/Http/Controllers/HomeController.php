<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\DatosGeneralesFitbit;
use App\Models\FitbitActivityMonthlyData;
use App\Models\UserFitbitInfo;
use App\Models\Token;
use Illuminate\Support\Facades\Auth;

class HomeController extends Controller
{
    private function getEncodedIds()
    {
        $user = auth()->user(); // Obtener el usuario de sesión
        $tokens = Token::where('appUser', $user->name)->get(); // Obtener los tokens del usuario de sesión
        return $tokens->pluck('userID'); // Obtener los encoded_id de los tokens
    }

    public function index($encoded_id = null)
    {
        if (Auth::check()) {
            // Obtener el usuario autenticado actualmente
            $user = auth()->user();

            // Obtener los datos de Fitbit del usuario
            $encodedIds = $this->getEncodedIds();

            // Obtener los datos de la tabla datos_generales_fitbit relacionados con los tokens
            $datosGenerales = DatosGeneralesFitbit::whereIn('encoded_id', $encodedIds)->get();

            // Obtener los datos de active_minutes para los encoded_ids seleccionados
            $activeMinutes = FitbitActivityMonthlyData::whereIn('encoded_id', $encodedIds)
                ->select('encoded_id', 'date', 'active_minutes')
                ->get();

            // Filtrar los datos de active_minutes para el encoded_id seleccionado, si se proporciona
            if ($encoded_id) {
                $activeMinutes = $activeMinutes->where('encoded_id', $encoded_id);
            }

            // Formatear los datos de active_minutes para generar las gráficas
            $formattedActiveMinutes = [];
            foreach ($activeMinutes as $activityData) {
                $encodedId = $activityData->encoded_id;
                $date = \Carbon\Carbon::parse($activityData->date);
                $formattedActiveMinutes[$encodedId]['dates'][] = $date->format('d-m');
                $formattedActiveMinutes[$encodedId]['activeMinutes'][] = $activityData->active_minutes;
            }

            // Pasar los datos a la vista
            return view('home', compact('datosGenerales', 'formattedActiveMinutes'));
        } else {
            return view('generic-home');
        }
    }
}
