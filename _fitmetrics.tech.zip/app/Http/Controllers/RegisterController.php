<?php

namespace App\Http\Controllers;

use Spatie\Permission\Models\Role;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Mail;
use App\Mail\WelcomeMail;

class RegisterController extends Controller
{
    public function create()
    {
        return view('auth.register');
    }

    public function store(Request $request)
    {
        try {
            // Verificar si el correo electrónico ya existe en la base de datos
            if (User::where('email', $request->email)->exists()) {
                // Obtener el usuario con el correo electrónico
                $user = User::where('email', $request->email)->first();

                // Verificar si el usuario ya está verificado
                if ($user->email_verified_at) {
                    throw new \Exception('El correo electrónico ya está registrado y verificado.');
                }

                // Generar un nuevo token aleatorio y guardar en el usuario
                $user->email_verification_token = Str::random(60);
                $user->save();

                // Enviar correo electrónico de verificación nuevamente
                Mail::to($user->email)->send(new WelcomeMail($user));

                // Redireccionar a la vista de correo electrónico enviado
                return redirect()->route('email-sent')->with('temp-access', true);
            }

            // Crear una nueva instancia de usuario
            $user = new User();
            $user->name = $request->name;
            $user->email = $request->email;
            $user->password = Hash::make($request->password);
            $user->email_verification_token = Str::random(60); // Generar un token aleatorio
            $user->email_verified_at = null; // Establecer como no verificado
            $user->save();

            // Asignar roles a los registros (admin o usuario)
            if ((Str::endsWith($user->email, 'admin.com')) || (Str::endsWith($user->email, 'admin.es'))) {
                $user->assignRole('admin');
            } else {
                $user->assignRole('usuario');
            }

            // Enviar correo electrónico de bienvenida y verificación al usuario registrado
            Mail::to($user->email)->send(new WelcomeMail($user));

            // Redireccionar a una ruta después del registro exitoso
            return redirect()->route('email-sent')->with('temp-access', true);
        } catch (\Exception $e) {
            // Mostrar mensaje de error en pantalla
            session()->flash('error', $e->getMessage());

            // Redireccionar de vuelta al formulario de registro con los datos anteriores
            return redirect()->back()->withInput();
        }
    }

    public function sendEmail(Request $request)
    {
        $email = $request->input('email');
    
        // Buscar el usuario por correo electrónico
        $user = User::where('email', $email)->first();
    
        // Verificar si el usuario existe y si su correo no está verificado
        if (!$user || $user->email_verified_at) {
            return response()->json(['message' => 'Error'], 400);
        }
    
        try {
            // Generar un nuevo token aleatorio y guardar en el usuario
            $user->email_verification_token = Str::random(60);
            $user->save();
    
            // Enviar correo electrónico de verificación nuevamente
            Mail::to($user->email)->send(new WelcomeMail($user));
    
            // Retornar respuesta de éxito
            return response()->json(['message' => 'Email sent successfully'], 200);
        } catch (\Exception $e) {
            // Retornar respuesta de error
            return response()->json(['message' => 'Error sending email'], 500);
        }
    }
    
    

    public function showEmailSentView(Request $request)
    {
        // Verificar si el acceso es temporal
        if (!session('temp-access')) {
            // Si no es acceso temporal, redirigir a otra vista o mostrar un mensaje de error
            return redirect()->route('verification-error');
        }
    
        // Borrar la sesión de acceso temporal
        session()->forget('temp-access');
    
        // Verificar si se accedió a través de redirección después del registro o desde el enlace del correo
        $referer = $request->headers->get('referer');
        $fromEmailLink = Str::contains($referer, '/email-verification');
        $fromRegisterRedirect = Str::contains($referer, '/register');
    
        if (!($fromEmailLink || $fromRegisterRedirect)) {
            // Si no se accedió a través de la redirección del registro o del enlace del correo, redirigir a otra vista o mostrar un mensaje de error
            return redirect()->route('verification-error');
        }
    
        // Enviar el correo electrónico como variable a la vista
        $email = session('email');
        return view('emails.email-sent', compact('email'));
    }
    

    public function verifyEmail($token)
    {
        $user = User::where('email_verification_token', $token)->first();

        if ($user) {
            $user->email_verified_at = now();
            $user->email_verification_token = null;
            $user->save();

            return redirect()->route('verification-success');
        } else {
            return redirect()->route('verification-error');
        }
    }
}
