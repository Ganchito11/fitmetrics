<?php

namespace App\Http\Controllers;

use http\Client\Curl\User; // Importar la clase User del espacio de nombres http\Client\Curl
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth; // Importar la fachada de autenticación
use Illuminate\Support\Facades\Log; // Importar la fachada de registro
use Illuminate\Http\RedirectResponse;

class SessionsController extends Controller
{
    public function login()
    {
        return view('auth.login');
    }

    public function doLogin(Request $request)
    {
        Log::error('antes de validar');
        $credentials = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required'],
        ]);
        //$credentials = $request->only(['email', 'password']);
        Log::error('flag1');

        if (Auth::attempt($credentials)) {
            Log::error('flag2');

            // Verificar si la cuenta de correo electrónico está verificada
            if (auth()->user()->email_verified_at) {
                // Inicio de sesión exitoso
                return redirect()->route('home');
            } else {
                Auth::logout();
                return back()
                    ->withErrors(['email' => 'La cuenta no ha sido verificada por correo electrónico']);
            }
        }

        // Inicio de sesión fallido
        return back()->withErrors(['email' => 'Estas credenciales no coinciden con nuestros registros']);
    }

    public function logout(Request $request)
    {
        Auth::logout();
        return redirect()->route('home');
    }

    public function destroy($id)
    {
        Log::error('error1');

        $user = User::find($id); // Buscar el usuario por su ID
        Log::error('error2');
        $user->delete(); // Eliminar el usuario
        Log::error('error3');
        return redirect()->route('register');
    }
}

