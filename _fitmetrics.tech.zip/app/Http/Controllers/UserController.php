<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Token;
use App\Models\DatosGeneralesFitbit;
use App\Models\FitbitActivityMonthlyData;
use App\Models\UserFitbitInfo;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;


class UserController extends Controller
{

    private function getData()
    {
        $user = auth()->user();
        $tokens = Token::where('appUser', $user->name)->get();
        return ['tokens' => $tokens];
    }
    
    
    public function dashboard()
    {
        $data = $this->getData();
    
        return view('user', $data);
    }
  
    // Para eliminar el usuario al que está vinculado
    public function deleteUserToken(Request $request, $encoded_id)
    {
        $user = Auth::user(); // Obtener el usuario autenticado actualmente
        $tokenID = $request->input('selectedUser');
    
        // Buscar el token que coincida con el encoded_id y el appUser
        $token = Token::where('userID', $tokenID)
            ->where('appUser', $user->name)
            ->first();
    
        if ($token) {
            // Eliminar el token
            $token->delete();
    
            return redirect()->back()->with('success', 'Usuario eliminado con éxito');
        } else {
            return redirect()->back()->with('error', 'El usuario Fitbit seleccionado no está vinculado al usuario actual');
        }
    }
    

    public function changeTokenValue(Request $request)
    {
        // Obtener el usuario autenticado actualmente
        $user = Auth::user();
    
        // Obtener los userID seleccionados del formulario
        $encodedIds = $request->input('refreshEnabled', []); // Obtener los userID seleccionados del formulario
    
        // Actualizar el valor de refresh_enabled para todos los tokens del usuario
        Token::where('appUser', $user->name)
            ->update(['refresh_enabled' => 0]);
    
        // Actualizar el valor de refresh_enabled solo para los userID seleccionados
        Token::whereIn('userID', $encodedIds)
            ->update(['refresh_enabled' => 1]);
    
        // Obtener los tokens actualizados después de la modificación
        $tokens = Token::where('appUser', $user->name)->get();
    
        return view('user', ['tokens' => $tokens])->with('success', 'Valor de refresh_enabled actualizado correctamente.');
    }
       
     
    // Para descargar la información del usuario
    public function downloadUserInfo($id)
    {
        $data = $this->getData();
        
        // Obtener los userIds de los tokens
        $encodedIds = $data['tokens']->pluck('userID');

        // Obtener los datos de las tablas usando los userIds
        $datosGeneralesFitbit = DatosGeneralesFitbit::whereIn('encoded_id', $encodedIds)->get();
        $fitbitActivityMonthlyData = FitbitActivityMonthlyData::whereIn('encoded_id', $encodedIds)->get();
        $userFitbitInfo = UserFitbitInfo::whereIn('encoded_id', $encodedIds)->get();

        $userData = [
            'datosGeneralesFitbit' => $datosGeneralesFitbit,
            'fitbitActivityMonthlyData' => $fitbitActivityMonthlyData,
            'userFitbitInfo' => $userFitbitInfo
        ];

        $jsonData = json_encode($userData, JSON_PRETTY_PRINT);

        $fileName = 'user_data_' . $id . '.json';
        Storage::disk('local')->put($fileName, $jsonData);

        return response()->download(storage_path("app/{$fileName}"));
    }


    

    // Para borrar la cuenta del usuario
    public function deleteUser($id)
    {
        $user = User::findOrFail($id);
        $user->delete();

        return redirect()->route('home')->with('success', 'Usuario eliminado con éxito');
    }
}
