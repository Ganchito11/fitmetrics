<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DatosGeneralesFitbit extends Model
{
    use HasFactory;

    protected $table = 'datos_generales_fitbit';

    protected $fillable = [
        'encoded_id',
        'pasos',
        'plantas_subidas',
        'kilometros_recorridos',
        'calorias_quemadas',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
