<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SleepLevel extends Model
{
    use HasFactory;

    protected $fillable = [
        'sleep_session_id', 'datetime', 'level', 'seconds'
    ];

    public function sleepSession()
    {
        return $this->belongsTo(SleepSession::class);
    }
}
