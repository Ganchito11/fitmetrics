<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SleepLevelSummary extends Model
{
    use HasFactory;

    protected $fillable = [
        'sleep_session_id', 'level', 'minutes'
    ];

    public function sleepSession()
    {
        return $this->belongsTo(SleepSession::class);
    }
}
