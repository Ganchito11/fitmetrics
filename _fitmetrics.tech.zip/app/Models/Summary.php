<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Summary extends Model
{
    use HasFactory;

    protected $fillable = [
        'sleep_session_id', 'total_minutes_asleep', 'total_sleep_sessions', 'total_time_in_bed'
    ];

    public function sleepSession()
    {
        return $this->belongsTo(SleepSession::class);
    }

    public function summaryStages()
    {
        return $this->hasMany(SummaryStage::class);
    }
}

