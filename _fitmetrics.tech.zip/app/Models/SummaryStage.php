<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SummaryStage extends Model
{
    use HasFactory;

    protected $fillable = [
        'summary_id', 'deep', 'light', 'rem', 'wake'
    ];

    public function summary()
    {
        return $this->belongsTo(Summary::class);
    }
}
