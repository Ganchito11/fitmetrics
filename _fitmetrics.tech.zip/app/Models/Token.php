<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Token extends Model
{
    use HasFactory;

    protected $table = 'tokens';
    protected $primaryKey = 'userID';
    protected $keyType = 'string';
    public $timestamps = false;

    // Asegúrate de definir correctamente los campos de la tabla
    protected $fillable = [
        'userID',
        'accessToken',
        'refreshToken',
        'appUser',
        'refresh_enabled',
        'lastUpdate',
    ];
}
