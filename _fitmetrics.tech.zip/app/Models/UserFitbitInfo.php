<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserFitbitInfo extends Model
{
    use HasFactory;

    protected $table = 'user_fitbit_info';

    protected $fillable = [
        'encoded_id',
        'full_name',
        'date_of_birth',
        'gender',
        'height',
        'weight',
        'avatar',
    ];
}
