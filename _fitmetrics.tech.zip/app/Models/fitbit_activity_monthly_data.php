namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FitbitActivityMonthlyData extends Model
{
    protected $table = 'fitbit_activity_monthly_data';

    protected $fillable = [
        'encoded_id',
        'active_minutes',
        'calories_out',
        'distance',
        'floors',
        'steps',
        'date',
        'active_score',
        'activity_calories',
        'calories_bmr',
        'elevation',
        'marginal_calories',
        'resting_heart_rate',
        'sedentary_minutes',
        'heart_rate_zones',
    ];

    protected $casts = [
        'heart_rate_zones' => 'array',
    ];
}
