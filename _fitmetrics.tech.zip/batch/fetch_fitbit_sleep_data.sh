#!/bin/bash

# Imprimir la hora de ejecución
echo "Hora de ejecución del batch: $(TZ='Europe/Madrid' date)"

# Obtener la ruta de la carpeta raíz en el servidor
rootPath=/home/u401132006/domains/fitmetrics.tech

# Obtener los registros de la tabla tokens
tokens=$(mysql --defaults-extra-file=$rootPath/mysql_credentials.cnf -Bse "SELECT accessToken, userID FROM tokens")

# Obtener la fecha actual y la fecha hace 15 días
currentDate=$(date +%Y-%m-%d)
startDate=$(date +%Y-%m-%d -d "15 days ago")

# Iterar sobre los registros de tokens
while read -r token userID; do
  # Iterar desde la fecha de inicio hasta la fecha actual
  date=$startDate
  while [[ "$date" < "$currentDate" ]]; do
    # Obtener la información del sueño y guardar en un archivo temporal
    response=$(curl -s -w "%{http_code}" -H "Authorization: Bearer $token" "https://api.fitbit.com/1.2/user/-/sleep/date/$date.json")
    httpCode="${response:${#response}-3}"

    # Verificar si se pudo leer el archivo JSON del sueño
    if [ "$httpCode" != "200" ]; then
      echo "Error al obtener los datos del sueño para la fecha $date. Código de estado HTTP: $httpCode"
      continue
    fi

    # Extraer la respuesta JSON sin el código de estado
    json="${response:0:${#response}-3}"

    # Imprimir la respuesta del cURL
    echo "Respuesta del cURL para la fecha $date y usuario $userID:"
    echo "$json"

    # Guardar la respuesta en un archivo temporal
    echo "$json" > $rootPath/temp/fitbit_sleep.json

    # Ejecutar el archivo PHP para procesar los datos del sueño
    php "$rootPath/batch/script_sleep_data.php" "$userID" "$date"

    # Incrementar la fecha en un día
    date=$(date +%Y-%m-%d -d "$date + 1 day")
  done
done <<<"$tokens"
