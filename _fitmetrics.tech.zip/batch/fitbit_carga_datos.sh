#!/bin/bash

# Imprimir la hora de ejecución
echo "Hora de ejecución del batch: $(TZ='Europe/Madrid' date)"

# Obtener la ruta de la carpeta anterior EN DEVELOPMENT
#rootPath=$(dirname "$PWD") #Esto se refiere a la carpeta raiz

#RUTA EN SERVIDOR
rootPath=/home/u401132006/domains/fitmetrics.tech

# Obtener los registros de la tabla tokens EN PROD
tokens=$(mysql --defaults-extra-file=$rootPath/mysql_credentials.cnf -Bse "SELECT accessToken, userID FROM tokens")


# Iterar sobre los registros de tokens
while read -r token userID; do

  # Obtener el perfil del usuario y guardar en un archivo temporal
  curl -s -X GET "https://api.fitbit.com/1/user/-/profile.json" \
  -H "accept: application/json" \
  -H "authorization: Bearer $token" > $rootPath/temp/fitbit_perfil.json
  
  # Verificar si se pudo leer el archivo JSON del perfil
  if [ ! -s "$rootPath/temp/fitbit_perfil.json" ]; then
    echo "Error al leer los datos del perfil en el archivo fitbit_perfil.json."
    continue
  fi
  
  # Verificar si la respuesta es válida utilizando herramientas de línea de comandos
  errorType=$(grep -o '"errorType":"[^"]*' "$rootPath/temp/fitbit_perfil.json" | sed 's/"errorType":"//')

  # Obtener el código de estado de la respuesta
  responseStatus=$(curl -s -o /dev/null -w "%{http_code}" "https://api.fitbit.com/1/user/-/profile.json" \
    -H "accept: application/json" \
    -H "authorization: Bearer $token")

  # Verificar si la respuesta es válida
  if [ -z "$userID" ] || [ "$responseStatus" != "200" ]; then
    echo "Respuesta inválida. No se ejecutará el script PHP / ResponseStatus: $responseStatus / ErrorType: $errorType / UserID: $userID"
    continue
  fi
  # Ejecutar el archivo PHP
  php "$rootPath/batch/script_user_profile.php"

  # Obtener la fecha actual
  currentDate=$(date +%Y-%m-%d)

  # Obtener la información general de actividades y guardar en un archivo temporal
  curl -s -H "Authorization: Bearer $token" "https://api.fitbit.com/1/user/-/activities/date/$currentDate.json" > $rootPath/temp/fitbit_activities.json

  # Verificar si se pudo leer el archivo JSON de las actividades
  if [ ! -s "$rootPath/temp/fitbit_activities.json" ]; then
    echo "Error al leer los datos de actividades en el archivo fitbit_activities.json."
    continue
  fi

  # Ejecutar el archivo PHP para procesar los datos de actividades
  php "$rootPath/batch/script_activities_data.php" "$userID"

done <<<"$tokens"
