#!/bin/bash

# Imprimir la hora de ejecución
echo "Hora de ejecución del batch: $(TZ='Europe/Madrid' date)"

# Obtener la ruta de la carpeta raíz en el servidor
rootPath=/home/u401132006/domains/fitmetrics.tech

# Obtener los registros de la tabla tokens
tokens=$(mysql --defaults-extra-file=$rootPath/mysql_credentials.cnf -Bse "SELECT accessToken, userID FROM tokens")

# Obtener la fecha actual y la fecha hace 31 días
currentDate=$(date +%Y-%m-%d)
startDate=$(date +%Y-%m-%d -d "31 days ago")

# Iterar sobre los registros de tokens
while read -r token userID; do
  # Iterar desde la fecha de inicio hasta la fecha actual
  date=$startDate
  while [[ "$date" < "$currentDate" ]]; do
    # Obtener la información general de actividades y guardar en un archivo temporal
    curl -s -H "Authorization: Bearer $token" "https://api.fitbit.com/1/user/-/activities/date/$date.json" > $rootPath/temp/fitbit_activities.json

    # Verificar si se pudo leer el archivo JSON de las actividades
    if [ ! -s "$rootPath/temp/fitbit_activities.json" ]; then
      echo "Error al leer los datos de actividades en el archivo fitbit_activities.json."
      continue
    fi

    # Ejecutar el archivo PHP para procesar los datos de actividades
    php "$rootPath/batch/script_activities_monthly_data.php" "$userID" "$date"

    # Incrementar la fecha en un día
    date=$(date +%Y-%m-%d -d "$date + 1 day")
  done
done <<<"$tokens"
