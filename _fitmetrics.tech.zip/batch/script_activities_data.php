<?php

// Verificar si se proporcionó el argumento de encodedId
if ($argc < 2) {
    echo "Debe proporcionar el encodedId como argumento." . PHP_EOL;
    exit;
}

$encodedId = $argv[1]; // Obtener el encodedId del argumento

// Ruta de la raíz en DEV
#$rootPath = dirname(__DIR__);

#RUTA EN SERVIDOR
$rootPath = '/home/u401132006/domains/fitmetrics.tech';

// Ruta del archivo JSON con los datos de las actividades
$actividadesFile = $rootPath . '/temp/fitbit_activities.json';

// Leer el contenido del archivo JSON
$jsonData = file_get_contents($actividadesFile);

// Decodificar el JSON en un arreglo asociativo
$actividadesData = json_decode($jsonData, true);

if ($actividadesData === null) {
    echo "Error al decodificar el archivo JSON de las actividades." . PHP_EOL;
    exit;
}

// Verificar si se obtuvieron correctamente los datos de las actividades
if ($actividadesData && isset($actividadesData['summary'])) {
    $pasos = $actividadesData['summary']['steps'];
    $floors = $actividadesData['summary']['floors'];
    $distances = $actividadesData['summary']['distances'];
    $kilometros = 0;
    foreach ($distances as $distance) {
        if ($distance['activity'] === 'total') {
            $kilometros = $distance['distance'];
            break;
        }
    }
    $calorias = $actividadesData['summary']['caloriesOut'];

    // EN PROD
    $dsn = 'mysql:host=127.0.0.1;dbname=u401132006_tfg_fitbit';
    $username = 'u401132006_Fran';
    $password = 'Ganchito_985';

    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ];

    try {
        // Crear una instancia de PDO
        $pdo = new PDO($dsn, $username, $password, $options);

        // Obtener la fecha y hora actual ajustada a +2 horas
        $currentTimestamp = date('Y-m-d H:i:s', strtotime('+2 hours'));

        // Verificar si el encodedId ya existe en la tabla datos_generales_fitbit
        $sqlCheckEncodedId = 'SELECT * FROM datos_generales_fitbit WHERE encoded_id = ?';
        $stmtCheckEncodedId = $pdo->prepare($sqlCheckEncodedId);
        $stmtCheckEncodedId->execute([$encodedId]);
        $encodedIdExists = $stmtCheckEncodedId->rowCount() > 0;


    if ($encodedIdExists) {
        // Actualizar los valores en la tabla datos_generales_fitbit
        $sqlUpdate = 'UPDATE datos_generales_fitbit
                    SET pasos = ?,
                        plantas_subidas = ?,
                        kilometros_recorridos = ?,
                        calorias_quemadas = ?,
                        updated_at = ?
                    WHERE encoded_id = ?'; // Añadir la cláusula WHERE para actualizar solo el registro correspondiente al encodedId
        $stmtUpdate = $pdo->prepare($sqlUpdate);
        $stmtUpdate->execute([$pasos, $floors, $kilometros, $calorias, $currentTimestamp, $encodedId]);

        echo "Datos de las actividades del usuario $encodedId actualizados correctamente." . PHP_EOL;
    } else {
        // Insertar los datos en la tabla datos_generales_fitbit
        $sqlInsert = 'INSERT INTO datos_generales_fitbit (encoded_id, pasos, plantas_subidas, kilometros_recorridos, calorias_quemadas, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?)';
        $stmtInsert = $pdo->prepare($sqlInsert);
        $stmtInsert->execute([$encodedId, $pasos, $floors, $kilometros, $calorias, $currentTimestamp, $currentTimestamp]);

        echo "Datos de las actividades del usuario $encodedId insertados correctamente." . PHP_EOL;
}

    } catch (PDOException $e) {
        echo "Error al conectar a la base de datos: " . $e->getMessage() . PHP_EOL;
    }
} else {
    echo "Error al leer los datos de las actividades." . PHP_EOL;
}
?>
