<?php

// Verificar si se proporcionó el argumento de encodedId y la fecha
if ($argc < 3) {
    echo "Debe proporcionar el encodedId y el date como argumento." . PHP_EOL;
    exit;
}

$encodedId = $argv[1]; // Obtener el encodedId del argumento
$date = $argv[2];

$rootPath = '/home/u401132006/domains/fitmetrics.tech';

// Ruta del archivo JSON con los datos de las actividades
$activitiesFile = $rootPath . '/temp/fitbit_activities.json';

// Leer el contenido del archivo JSON
$jsonData = file_get_contents($activitiesFile);

// Decodificar el JSON en un arreglo asociativo
$activitiesData = json_decode($jsonData, true);

if ($activitiesData === null) {
    echo "Error al decodificar el archivo JSON de las actividades." . PHP_EOL;
    exit;
}

// Verificar si se obtuvieron correctamente los datos de las actividades
if ($activitiesData && isset($activitiesData['summary'])) {
    $activeMinutes = $activitiesData['summary']['fairlyActiveMinutes'] + $activitiesData['summary']['veryActiveMinutes'];
    $caloriesOut = $activitiesData['summary']['caloriesOut'];
    $distance = 0;
    foreach ($activitiesData['summary']['distances'] as $dist) {
        if ($dist['activity'] === 'total') {
            $distance = $dist['distance'];
            break;
        }
    }
    $floors = $activitiesData['summary']['floors'];
    $steps = $activitiesData['summary']['steps'];
    
    // Obtener los datos adicionales del JSON
    $activeScore = $activitiesData['summary']['activeScore'];
    $activityCalories = $activitiesData['summary']['activityCalories'];
    $caloriesBMR = $activitiesData['summary']['caloriesBMR'];
    $elevation = $activitiesData['summary']['elevation'];
    $marginalCalories = $activitiesData['summary']['marginalCalories'];
    $restingHeartRate = $activitiesData['summary']['restingHeartRate'];
    $sedentaryMinutes = $activitiesData['summary']['sedentaryMinutes'];
    $heartRateZones = json_encode($activitiesData['summary']['heartRateZones']);

    // EN PROD
    $dsn = 'mysql:host=127.0.0.1;dbname=u401132006_tfg_fitbit';
    $username = 'u401132006_Fran';
    $password = 'Ganchito_985';

    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ];

    try {
        // Crear una instancia de PDO
        $pdo = new PDO($dsn, $username, $password, $options);

        // Obtener la fecha y hora actual ajustada a +2 horas
        $currentTimestamp = date('Y-m-d H:i:s', strtotime('+2 hours'));

        // Verificar si el encodedId ya existe en la tabla fitbit_activity_monthly_data para la fecha dada
        $sqlCheckEncodedId = 'SELECT * FROM fitbit_activity_monthly_data WHERE encoded_id = ? AND date = ?';
        $stmtCheckEncodedId = $pdo->prepare($sqlCheckEncodedId);
        $stmtCheckEncodedId->execute([$encodedId, $date]);
        $encodedIdExists = $stmtCheckEncodedId->rowCount() > 0;

        if ($encodedIdExists) {
            // Actualizar los valores en la tabla fitbit_activity_monthly_data para la fecha dada
            $sqlUpdate = 'UPDATE fitbit_activity_monthly_data
                          SET active_minutes = ?,
                              calories_out = ?,
                              distance = ?,
                              floors = ?,
                              steps = ?,
                              updated_at = ?,
                              active_score = ?,
                              activity_calories = ?,
                              calories_bmr = ?,
                              elevation = ?,
                              marginal_calories = ?,
                              resting_heart_rate = ?,
                              sedentary_minutes = ?,
                              heart_rate_zones = ?
                          WHERE encoded_id = ? AND date = ?';
            $stmtUpdate = $pdo->prepare($sqlUpdate);

            $stmtUpdate->execute([
                $activeMinutes,
                $caloriesOut,
                $distance,
                $floors,
                $steps,
                $currentTimestamp,
                $activeScore,
                $activityCalories,
                $caloriesBMR,
                $elevation,
                $marginalCalories,
                $restingHeartRate,
                $sedentaryMinutes,
                $heartRateZones,
                $encodedId,
                $date
            ]);

            echo "Datos de las actividades del usuario $encodedId del dia $date actualizados correctamente." . PHP_EOL;
        } else {
            // Eliminar las fechas que tienen más de 31 días en la tabla fitbit_activity_monthly_data
            $thresholdDate = date('Y-m-d', strtotime('-31 days'));
            $sqlDeleteOldDates = 'DELETE FROM fitbit_activity_monthly_data WHERE date < ?';
            $stmtDeleteOldDates = $pdo->prepare($sqlDeleteOldDates);

            // Debug: Imprimir valores antes de la ejecución de la consulta
            echo "Valores antes de la ejecución de la consulta DELETE:" . PHP_EOL;
            echo "thresholdDate: " . $thresholdDate . PHP_EOL;

            $stmtDeleteOldDates->execute([$thresholdDate]);

            // Insertar los datos en la tabla fitbit_activity_monthly_data para la fecha dada
            $sqlInsert = 'INSERT INTO fitbit_activity_monthly_data (encoded_id, active_minutes, calories_out, distance, floors, steps, created_at, updated_at, date, active_score, activity_calories, calories_bmr, elevation, marginal_calories, resting_heart_rate, sedentary_minutes, heart_rate_zones)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
            $stmtInsert = $pdo->prepare($sqlInsert);




            $stmtInsert->execute([
                $encodedId,
                $activeMinutes,
                $caloriesOut,
                $distance,
                $floors,
                $steps,
                $currentTimestamp,
                $currentTimestamp,
                $date,
                $activeScore,
                $activityCalories,
                $caloriesBMR,
                $elevation,
                $marginalCalories,
                $restingHeartRate,
                $sedentaryMinutes,
                $heartRateZones
            ]);

            echo "Datos de las actividades del usuario $encodedId insertados correctamente." . PHP_EOL;
        }
    } catch (PDOException $e) {
        echo "Error al conectar a la base de datos: " . $e->getMessage() . PHP_EOL;
        echo "Archivo: " . $e->getFile() . PHP_EOL;
        echo "Línea: " . $e->getLine() . PHP_EOL;
    }
} else {
    $lastError = error_get_last();
    echo "Error al leer los datos de las actividades: " . $lastError['message'] . PHP_EOL;
    echo "Archivo: " . $lastError['file'] . PHP_EOL;
    echo "Línea: " . $lastError['line'] . PHP_EOL;
}

?>
