<?php

// Verificar si se proporcionó el argumento de encodedId
if ($argc < 2) {
    echo "Debe proporcionar el encodedId como argumento." . PHP_EOL;
    exit;
}

$encodedId = $argv[1]; // Obtener el encodedId del argumento

// Ruta de la raíz en DEV
#$rootPath = dirname(__DIR__);

#RUTA EN SERVIDOR
$rootPath = '/home/u401132006/domains/fitmetrics.tech';

// Ruta del archivo JSON con los datos de las actividades
$heartrateFile = $rootPath . '/temp/fitbit_heartrate.json';

// Leer el contenido del archivo JSON
$jsonData = file_get_contents($heartrateFile);

// Decodificar el JSON en un arreglo asociativo
$heartrateData = json_decode($jsonData, true);

if ($heartrateData === null) {
    echo "Error al decodificar el archivo JSON de la frecuencia cardíaca." . PHP_EOL;
    exit;
}

// Verificar si se obtuvieron correctamente los datos de la frecuencia cardíaca
if ($heartrateData && isset($heartrateData['activities-heart'])) {
    foreach ($heartrateData['activities-heart'] as $data) {
        $date = $data['dateTime'];
        $heartrate = $data['value']['restingHeartRate'];

        // EN PROD
        $dsn = 'mysql:host=127.0.0.1;dbname=u401132006_tfg_fitbit';
        $username = 'u401132006_Fran';
        $password = 'Ganchito_985';

        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ];

        try {
            // Crear una instancia de PDO
            $pdo = new PDO($dsn, $username, $password, $options);

            // Insertar los datos en la tabla heartrate
            $sqlInsert = 'INSERT INTO heartrate (encoded_id, date, heartrate)
                          VALUES (?, ?, ?)';
            $stmtInsert = $pdo->prepare($sqlInsert);
            $stmtInsert->execute([$encodedId, $date, $heartrate]);

            echo "Datos de la frecuencia cardíaca del usuario $encodedId insertados correctamente." . PHP_EOL;
        } catch (PDOException $e) {
            echo "Error al conectar a la base de datos: " . $e->getMessage() . PHP_EOL;
        }
    }
} else {
    echo "Error al leer los datos de la frecuencia cardíaca." . PHP_EOL;
}
?>
