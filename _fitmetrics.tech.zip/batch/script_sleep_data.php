<?php

if ($argc < 3) {
    echo "Debe proporcionar el userID y la fecha como argumentos." . PHP_EOL;
    exit;
}

$userID = $argv[1];
$date = $argv[2];
$rootPath = '/home/u401132006/domains/fitmetrics.tech';

$sleepFile = $rootPath . '/temp/fitbit_sleep.json';
$jsonData = file_get_contents($sleepFile);
$sleepData = json_decode($jsonData, true);

if ($sleepData === null) {
    echo "Error al decodificar el archivo JSON del sueño." . PHP_EOL;
    exit;
}

if (empty($sleepData['sleep'])) {
    echo "Ningún dato para esa fecha." . PHP_EOL;
    exit;
}

$dsn = 'mysql:host=127.0.0.1;dbname=u401132006_tfg_fitbit';
$username = 'u401132006_Fran';
$password = 'Ganchito_985';

$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
];

try {
    $pdo = new PDO($dsn, $username, $password, $options);

    // Eliminar las filas donde la columna 'date' sea más antigua de 16 días
    $thresholdDate = date('Y-m-d', strtotime('-16 days'));
    $query = "DELETE FROM sleep_sessions WHERE date < ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$thresholdDate]);

    foreach ($sleepData['sleep'] as $session) {
        $startTime = $session['startTime'];
        $endTime = $session['endTime'];
        $summary = json_encode($session['levels']['summary']);
        $data = json_encode($session['levels']['data']);
        $now = date('Y-m-d H:i:s');

        // Verificar si ya existe una fila con el mismo user_id y start_time
        $query = "SELECT id FROM sleep_sessions WHERE user_id = ? AND start_time = ?";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$userID, $startTime]);
        $existingRow = $stmt->fetch();

        if ($existingRow) {
            // Actualizar la fila existente
            $query = "UPDATE sleep_sessions SET end_time = ?, summary = ?, data = ?, updated_at = ? WHERE id = ?";
            $stmt = $pdo->prepare($query);
            $stmt->execute([$endTime, $summary, $data, $now, $existingRow['id']]);
        } else {
            // Insertar una nueva fila
            $query = "INSERT INTO sleep_sessions (user_id, date, start_time, end_time, summary, data, created_at, updated_at) 
                      VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $pdo->prepare($query);
            $stmt->execute([$userID, $date, $startTime, $endTime, $summary, $data, $now, $now]);
        }
    }

    echo "Datos del sueño almacenados en la base de datos." . PHP_EOL;

} catch (PDOException $e) {
    echo "Error al conectar a la base de datos: " . $e->getMessage() . PHP_EOL;
}
