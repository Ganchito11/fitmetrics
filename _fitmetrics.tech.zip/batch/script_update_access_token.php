<?php

require 'vendor/autoload.php';

use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;

// Obtener los registros de la tabla tokens
$tokens = shell_exec("mysql --defaults-extra-file=/home/u401132006/domains/fitmetrics.tech/mysql_config.cnf -h localhost -u u401132006_Fran -pGanchito_985 -D u401132006_tfg_fitbit -Bse \"SELECT accessToken, refreshToken FROM tokens\"");

// Convertir los registros en un array
$tokensArray = explode(PHP_EOL, trim($tokens));

// Recorrer los tokens y actualizar el accessToken
foreach ($tokensArray as $token) {
    $tokenData = explode("\t", $token);
    $refreshToken = $tokenData[1];

    echo "Procesando refreshToken: $refreshToken" . PHP_EOL;

    try {
        // Crear el cliente HTTP
        $client = new Client();

        // Enviar la solicitud para refrescar el token
        $response = $client->request('POST', 'https://api.fitbit.com/oauth2/token', [
            'form_params' => [
                'grant_type' => 'refresh_token',
                'refresh_token' => $refreshToken,
            ],
            'auth' => ['client_id', 'client_secret'], // reemplaza 'client_id' y 'client_secret' con los valores apropiados
        ]);

        // Decodificar la respuesta JSON
        $data = json_decode($response->getBody(), true);

        // Obtener el nuevo accessToken de la respuesta
        $newAccessToken = $data['access_token'];

        // Actualizar el accessToken en la base de datos si se obtuvo uno nuevo
        if (!empty($newAccessToken)) {
            $query = "UPDATE tokens SET accessToken = '$newAccessToken' WHERE refreshToken = '$refreshToken'";
            shell_exec("mysql --defaults-extra-file=/home/u401132006/domains/fitmetrics.tech/mysql_config.cnf -h localhost -u u401132006_Fran -pGanchito_985 -D u401132006_tfg_fitbit -e \"$query\"");
            echo "AccessToken actualizado para refreshToken: $refreshToken" . PHP_EOL;
        } else {
            echo "Error al actualizar el accessToken para refreshToken: $refreshToken" . PHP_EOL;
        }
    } catch (RequestException $e) {
        echo "Error en la solicitud POST a Fitbit para refrescar el token de acceso: " . $e->getMessage() . PHP_EOL;
    }
}
