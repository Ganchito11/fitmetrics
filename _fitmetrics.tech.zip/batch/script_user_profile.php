<?php
// Ruta de la raíz en DEV
#$rootPath = dirname(__DIR__);

#RUTA EN SERVIDOR
$rootPath = '/home/u401132006/domains/fitmetrics.tech';

// Ruta del archivo JSON con los datos del perfil
$profileFile = $rootPath . '/temp/fitbit_perfil.json';

// Leer el contenido del archivo JSON
$jsonData = file_get_contents($profileFile);

// Decodificar el JSON en un arreglo asociativo
$profileData = json_decode($jsonData, true);

if ($profileData === null) {
    echo "Error al decodificar el archivo JSON del perfil." . PHP_EOL;
    exit;
}

// Verificar si se obtuvo correctamente el perfil del usuario
if ($profileData && isset($profileData['user'])) {
    // Extraer los datos relevantes del perfil
    $encodedId = $profileData['user']['encodedId'];
    $fullName = $profileData['user']['fullName'];
    $dateOfBirth = $profileData['user']['dateOfBirth'];
    $gender = $profileData['user']['gender'];
    $height = $profileData['user']['height'];
    $weight = $profileData['user']['weight'];
    $avatarUrl = $profileData['user']['avatar640'];

    //EN PROD
    $dsn = 'mysql:host=127.0.0.1;dbname=u401132006_tfg_fitbit';
    $username = 'u401132006_Fran';
    $password = 'Ganchito_985';
    
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ];

    try {
        // Crear una instancia de PDO
        $pdo = new PDO($dsn, $username, $password, $options);
        
        // Obtener la fecha y hora actual ajustada a +2 horas
        $currentTimestamp = date('Y-m-d H:i:s', strtotime('+2 hours'));

        // Comprobar si el usuario ya existe en la base de datos
        $sqlCheckUser = 'SELECT * FROM user_fitbit_info WHERE encoded_id = ?';
        $stmtCheckUser = $pdo->prepare($sqlCheckUser);
        $stmtCheckUser->execute([$encodedId]);
        $userExists = $stmtCheckUser->rowCount() > 0;

        if ($userExists) {
            // Actualizar los datos en la tabla user_fitbit_info
            $sqlUpdate = 'UPDATE user_fitbit_info
                          SET full_name = ?,
                              date_of_birth = ?,
                              gender = ?,
                              height = ?,
                              weight = ?,
                              avatar = ?,
                              updated_at = ?
                          WHERE encoded_id = ?';  // Agregar la condición WHERE
            $stmtUpdate = $pdo->prepare($sqlUpdate);
            $stmtUpdate->execute([$fullName, $dateOfBirth, $gender, $height, $weight, $avatarUrl, $currentTimestamp, $encodedId]);  // Agregar el valor de encodedId

            echo "Datos del perfil del usuario $encodedId actualizados correctamente." . PHP_EOL;
        } else {
            // Insertar los datos en la tabla user_fitbit_info
            $sqlInsert = 'INSERT INTO user_fitbit_info (encoded_id, full_name, date_of_birth, gender, height, weight, avatar, created_at, updated_at)
                          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)';
            $stmtInsert = $pdo->prepare($sqlInsert);
            $stmtInsert->execute([$encodedId, $fullName, $dateOfBirth, $gender, $height, $weight, $avatarUrl, $currentTimestamp, $currentTimestamp]);

            echo "Datos del perfil del usuario $encodedId insertados correctamente." . PHP_EOL;
        }
    } catch (PDOException $e) {
        echo "Error al conectar a la base de datos: " . $e->getMessage() . PHP_EOL;
    }
} else {
    echo "Error al leer los datos del perfil." . PHP_EOL;
}
?>
