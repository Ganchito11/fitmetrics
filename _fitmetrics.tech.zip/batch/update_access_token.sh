#!/bin/bash

# Imprimir la hora de ejecución
echo "Hora de ejecución del batch: $(TZ='Europe/Madrid' date)"

# Obtener la ruta de la carpeta raíz en el servidor
rootPath=/home/u401132006/domains/fitmetrics.tech

# Configuración de cliente OAuth2
clientID="238NMS"
clientSecret="d57ecbed856d07c3ae0348df9f2d7542"

tokens=$(mysql --defaults-extra-file=$rootPath/mysql_credentials.cnf -Bse "SELECT refreshToken, userID FROM tokens WHERE refresh_enabled = 1")


# Iterar sobre los tokens y los userID correspondientes
while IFS=$'\t' read -r refreshToken userID; do

  # Crear el cliente HTTP
  client="curl"

  # Crear el encabezado de autorización
  authorizationHeader="Basic $(echo -n "$clientID:$clientSecret" | base64)"

  # Enviar la solicitud para refrescar el token y obtener la respuesta
  response=$($client -s -X POST \
    https://api.fitbit.com/oauth2/token \
    -H "Authorization: $authorizationHeader" \
    -H "Content-Type: application/x-www-form-urlencoded" \
    --data "grant_type=refresh_token" \
    --data "refresh_token=$refreshToken")

  # Imprimir la respuesta de la solicitud
  echo "Respuesta de la solicitud:"
  echo "$response"

  # Verificar el código de respuesta HTTP 
  if [[ $httpCode -ne 200 ]]; then
    # Obtener el nuevo accessToken, refreshToken y lastUpdate de la respuesta
    accessToken=$(echo "$response" | grep -o '"access_token":"[^"]*"' | sed 's/"access_token":"\([^"]*\)"/\1/')
    newRefreshToken=$(echo "$response" | grep -o '"refresh_token":"[^"]*"' | sed 's/"refresh_token":"\([^"]*\)"/\1/')
    lastUpdate=$(date +"%Y-%m-%d %H:%M:%S")

    echo "newRefreshToken"
    echo "$newRefreshToken"

    # Actualizar el accessToken, refreshToken y lastUpdate en la base de datos si se obtuvieron nuevos
    if [[ ! -z "$accessToken" && ! -z "$newRefreshToken" ]]; then
      query="UPDATE tokens SET accessToken = '$accessToken', refreshToken = '$newRefreshToken', lastUpdate = '$lastUpdate' WHERE refreshToken = '$refreshToken' AND userID = '$userID'"
    mysql --defaults-extra-file=/home/u401132006/domains/fitmetrics.tech/mysql_credentials.cnf -e "$query"
      echo "Tokens actualizados para userID: $userID"
    else
      echo "Error al actualizar los tokens para userID: $userID"
    fi
  fi
done <<< "$tokens"
