<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUserFitbitInfoTable extends Migration
{
    public function up()
    {
        Schema::create('user_fitbit_info', function (Blueprint $table) {
            $table->string('encoded_id')->primary();
            $table->string('full_name');
            $table->date('date_of_birth');
            $table->string('gender');
            $table->float('height');
            $table->float('weight');
            $table->string('avatar')->nullable(); 
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('user_fitbit_info');
    }
}
