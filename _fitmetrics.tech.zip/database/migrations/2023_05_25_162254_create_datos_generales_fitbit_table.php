<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDatosGeneralesFitbitTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('datos_generales_fitbit', function (Blueprint $table) {
            $table->string('encoded_id')->primary();
            $table->integer('pasos');
            $table->integer('plantas_subidas');
            $table->decimal('kilometros_recorridos', 8, 2);
            $table->decimal('calorias_quemadas', 8, 2);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('datos_generales_fitbit');
    }
}
