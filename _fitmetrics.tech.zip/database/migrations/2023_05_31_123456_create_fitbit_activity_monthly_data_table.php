<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateFitbitActivityMonthlyDataTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('fitbit_activity_monthly_data', function (Blueprint $table) {
            $table->id();
            $table->string('encoded_id');
            $table->integer('active_minutes');
            $table->integer('calories_out');
            $table->float('distance');
            $table->integer('floors');
            $table->integer('steps');
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->nullable();
            $table->date('date');
            $table->integer('active_score')->nullable();
            $table->integer('activity_calories')->nullable();
            $table->integer('calories_bmr')->nullable();
            $table->integer('elevation')->nullable();
            $table->integer('marginal_calories')->nullable();
            $table->integer('resting_heart_rate')->nullable();
            $table->integer('sedentary_minutes')->nullable();
            $table->json('heart_rate_zones')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('fitbit_activity_monthly_data');
    }
}
