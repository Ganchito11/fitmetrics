import Chart from 'chart.js/auto';
require('chart.js');
import 'chartjs-adapter-date-fns';
window.Chart = Chart;

