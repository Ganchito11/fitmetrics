@extends('layouts.app')
@section('title','Login')

@section('content')
<style>
    form {
        overflow: hidden;
        position: relative;
        width: 40%;
        height: 800px;
        margin: 0 auto;
    }
</style>

<form class="text-center" action="{{ route('do-login') }}" method="POST">
    @csrf
    <div class="mb-3">
        <label for="exampleInputEmail1" class="form-label">Dirección de Email</label>
        <input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
        <div id="emailHelp" class="form-text">¡No compartiremos tu correo con nadie!.</div>
    </div>
    <div class="mb-3">
        <label for="exampleInputPassword1" class="form-label">Contraseña</label>
        <input type="password" name="password" class="form-control" id="exampleInputPassword1">
    </div>
    <button type="submit" class="btn btn-primary">Enviar</button>

    <!-- Aquí mostramos los mensajes de error si los hay -->
    @if ($errors->any())
        <div class="alert alert-danger mt-3">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    @if(session('verification_message'))
        <div class="alert alert-info">
            {{ session('verification_message') }}
        </div>
    @endif
</form>
@endsection
