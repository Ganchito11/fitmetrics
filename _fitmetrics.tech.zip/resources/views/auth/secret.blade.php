@extends('layouts.app')
@section('title','Secret')

@section('content')


<h2>Pagina privada para admins</h2>


@endsection
