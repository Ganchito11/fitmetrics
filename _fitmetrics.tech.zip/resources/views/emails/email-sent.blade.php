@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                @if($errors->has('message'))
                    <div class="alert alert-danger" role="alert">
                        {{ $errors->first('message') }}
                    </div>
                @else
                    <div class="card">
                        <div class="card-header">Correo Electrónico enviado</div>
                        <div class="card-body">
                            <p>El Email de verificación ha sido enviado al correo indicado.</p>
                            <p>Por favor, revise su bandeja de entrada.</p>
                            <p>Si no ha recibido el correo electrónico, por favor, vuelva a registrarse.</p>
                        </div>
                    </div>
                @endif
            </div>
        </div>
    </div>
@endsection

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        $("#resend-link").on('click', function(e) {
            e.preventDefault(); // Prevenir la acción por defecto del enlace

            $.ajax({
                url: "{{ route('send-email', ['email' => $email]) }}",
                type: 'GET',
                success: function() {
                    alert("Email reenviado con éxito");
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    alert("Hubo un error al reenviar el email: " + jqXHR.responseText);
                }
            });
        });
    });
</script>

