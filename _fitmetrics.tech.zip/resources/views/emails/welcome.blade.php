@component('mail::message')
# E-mail de Verificación de Bienvenida

Tienes que verificar el correo electrónico para funcionar con el servicio CRUD de FitMetrics.
Por favor, haz clic en el siguiente botón para validar tu cuenta:

@component('mail::button', ['url' => route('verify-email', ['token' => $user->email_verification_token])])
Validar Correo Electrónico
@endcomponent

Gracias por tu tiempo.
@endcomponent

