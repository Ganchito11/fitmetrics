@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Actividad Física</h1>
        
        @if(isset($activityData['activities']) && count($activityData['activities']) > 0)
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Pasos</th>
                            <th>Distancia (km)</th>
                            <th>Calorías Quemadas</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($activityData['activities'] as $activity)
                            <tr>
                                <td>{{ $activity['dateTime'] }}</td>
                                <td>{{ $activity['steps'] }}</td>
                                <td>{{ $activity['distance'] }}</td>
                                <td>{{ $activity['calories'] }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @else
            <p>No se encontraron datos de actividad física.</p>
        @endif
    </div>
@endsection
