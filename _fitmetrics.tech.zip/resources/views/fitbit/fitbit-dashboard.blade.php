@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Panel Fitbit</h1>


        @if (Session::has('alert-warning'))
            <div class="alert alert-warning">
                {{ Session::get('alert-warning') }}
            </div>
        @endif


        <div class="row">
            <div class="col-md-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-fire"></i> Calorías quemadas</h5>
                        <p class="card-text">Ver información relacionada con las calorías quemadas.</p>
                        <a href="{{ route('fitbit.calories') }}" class="btn btn-primary">Ver Calorías</a>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-walking"></i> Pasos realizados</h5>
                        <p class="card-text">Ver información relacionada con los pasos realizados.</p>
                        <a href="{{ route('fitbit.steps') }}" class="btn btn-primary">Ver Pasos</a>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-heart"></i> Zonas de ritmo cardíaco</h5>
                        <p class="card-text">Ver información relacionada con las zonas de ritmo cardíaco.</p>
                        <a href="{{ route('fitbit.heart_zones') }}" class="btn btn-primary">Ver Ritmo Cardíaco</a>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-bed"></i> Sueño</h5>
                        <p class="card-text">Ver gráficas relacionadas con el sueño.</p>
                        <a href="{{ route('fitbit.sleep') }}" class="btn btn-primary">Ver Sueño</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12">
            <!-- Resumen de Datos Generales -->
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Resumen de Datos Generales del Día de Hoy (los datos se actualizan cada 5 minutos)</h5>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Encoded ID</th>
                                <th>Pasos</th>
                                <th>Plantas Subidas</th>
                                <th>Kilómetros Recorridos</th>
                                <th>Calorías Quemadas</th>
                                <th>Fecha de Creación</th>
                                <th>Fecha de Actualización</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($datosGenerales ?? [] as $datoGeneral)
                                <tr>
                                    <td>{{ $datoGeneral->encoded_id }}</td>
                                    <td>{{ $datoGeneral->pasos }}</td>
                                    <td>{{ $datoGeneral->plantas_subidas }}</td>
                                    <td>{{ $datoGeneral->kilometros_recorridos }}</td>
                                    <td>{{ $datoGeneral->calorias_quemadas }}</td>
                                    <td>{{ $datoGeneral->created_at }}</td>
                                    <td>{{ $datoGeneral->updated_at }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="text-center mt-4">
                <form id="generateDataForm" action="{{ route('fitbit.generateData') }}" method="POST">
                    @csrf
                    <button id="generateDataButton" type="submit" class="btn btn-success">Generar los Datos correspondientes a los últimos 31 días</button>
                </form>
            </div>
        </div>
    </div>

    <div id="loadingOverlay" class="overlay">
        <div class="loader"></div>
        <p id="loadingText">Cargando los datos de los últimos 31 días, por favor, NO CIERRE LA PÁGINA</p>
    </div>
@endsection




@push('styles')
    <link href="{{ asset('css/fitbit_dashboard.css') }}" rel="stylesheet">
@endpush


@push('scripts')
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('generateDataForm').addEventListener('submit', function() {
                document.getElementById('loadingOverlay').style.display = 'flex';
            });
        });
    </script>
@endpush
