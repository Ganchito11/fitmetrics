@extends('layouts.app')

@section('head')
    <link href="{{ asset('css/fitbit_users.css') }}" rel="stylesheet">
@endsection

@section('content')
    <div class="container">
        @if($UserFitbitInfo->isNotEmpty())
            <form id="userForm" method="post" action="{{ route('fitbit.showUserInfo', ['encoded_id' => '__encoded_id__']) }}" class="mb-3">
                @csrf
                <div class="input-group">
                    <label for="selectedUser" class="input-group-text">Selecciona un Usuario:</label>
                    <select name="selectedUser" id="selectedUser" class="form-select">
                        @foreach($UserFitbitInfo as $datos)
                            <option value="{{ $datos->encoded_id }}" {{ (isset($selectedUser) && $selectedUser == $datos->encoded_id) ? 'selected' : '' }}>
                                {{ $datos->encoded_id }}
                            </option>
                        @endforeach
                    </select>
                    <button type="submit" class="btn btn-primary">Obtener información del usuario</button>
                </div>
            </form>
        @endif

        @if(isset($selectedUser))
            @foreach($UserFitbitInfo as $datos)
                @if($datos->encoded_id == $selectedUser)
                    <div class="card">
                        <div class="row g-0">
                            <div class="col-md-4">
                                <img src="{{ $datos->avatar }}" class="img-fluid avatar-image" alt="AVATAR DE FITBIT">
                            </div>
                            <div class="col-md-8">
                                <div class="card-body">
                                    <h1 class="card-title"><strong>{{ $datos->full_name }}</strong></h1>
                                    <p class="card-text">Edad: {{ $age }}</p> <!-- Mostrar la edad -->
                                    <p class="card-text">Sexo: {{ ($datos->gender == 'MALE') ? 'Hombre' : 'Mujer' }}</p>
                                    <p class="card-text">Altura: {{ $datos->height }} cm</p>
                                    <p class="card-text">Peso: {{ $datos->weight }} kg</p>
                                    <a href="https://www.fitbit.com/user/{{ $datos->encoded_id }}" target="_blank" class="btn btn-info">Ver Perfil en Fitbit.com</a>
                                </div>
                            </div>
                        </div>
                    </div>
                @endif
            @endforeach
        @endif
    </div>

    <script>
        var form = document.getElementById('userForm');
        form.addEventListener('submit', function(event) {
            var selectedUser = document.getElementById('selectedUser').value;
            form.action = form.action.replace('__encoded_id__', selectedUser);
            event.preventDefault();
            window.location.href = form.action;
        });
    </script>
@endsection

@push('styles')
    <link href="{{ asset('css/fitbit_users.css') }}" rel="stylesheet">
@endpush
