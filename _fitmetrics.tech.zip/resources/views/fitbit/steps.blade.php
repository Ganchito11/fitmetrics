@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Gráficos de Pasos Realizados</h1>

    @if($UserFitbitInfo->isNotEmpty())
        <form id="userForm" method="get" action="{{ route('fitbit.showSteps', ['encoded_id' => '__encoded_id__']) }}" class="mb-3">
            <div class="input-group">
                <label for="selectedUser" class="input-group-text">Selecciona un Usuario:</label>
                <select name="selectedUser" id="selectedUser" class="form-select">
                    @foreach($UserFitbitInfo as $datos)
                        <option value="{{ $datos->encoded_id }}" {{ (isset($selectedUser) && $selectedUser == $datos->encoded_id) ? 'selected' : '' }}>
                            {{ $datos->encoded_id }}
                        </option>
                    @endforeach
                </select>
                <button type="submit" class="btn btn-primary">Obtener información del usuario</button>
            </div>
        </form>
    @endif

    <div class="card">
        <div class="card-body">
            <canvas id="stepsChart" style="height: 700px;"></canvas>
        </div>
    </div>
</div>

@push('scripts')
<script src="{{ asset('js/app.js') }}"></script>
<script>
    var form = document.getElementById('userForm');
    form.addEventListener('submit', function(event) {
        var selectedUser = document.getElementById('selectedUser').value;
        form.action = form.action.replace('__encoded_id__', selectedUser);
        event.preventDefault();
        window.location.href = form.action;
    });
</script>
<script>
    var chart;
    document.addEventListener("DOMContentLoaded", function() {
        var stepsData = @json($stepsData); // Convertir los datos de PHP a JSON
        
        // Ordenar los datos en orden cronológico
        stepsData.sort(function(a, b) {
            return new Date(a.date) - new Date(b.date);
        });
        
        var dates = stepsData.map(function(data) {
            return data.date;
        });
        
        var steps = stepsData.map(function(data) {
            return data.steps; // Corregir el acceso a la propiedad 'steps'
        });

        // Antes de crear el nuevo gráfico, destruir el anterior si existe
        if (chart) {
            chart.destroy();
        }
        
        // Configurar el gráfico
        var ctx = document.getElementById("stepsChart").getContext("2d");
        chart = new Chart(ctx, {
            type: "line",
            data: {
                labels: dates,
                datasets: [{
                    label: "Pasos Realizados a lo Largo del Día",
                    data: steps,
                    backgroundColor: "rgba(75, 192, 192, 0.2)",
                    borderColor: "rgba(75, 192, 192, 1)",
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: {
                        type: "time",
                        time: {
                            unit: "day"
                        }
                    },
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    });
</script>
@endpush

@endsection
