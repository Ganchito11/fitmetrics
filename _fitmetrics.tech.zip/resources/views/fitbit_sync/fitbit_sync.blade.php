@extends('layouts.app')

@section('content')
    <div class="container">
        <h1 class="mb-4">Sincronización con Fitbit</h1>

        @if (session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif

        @if (session('error'))
            <div class="alert alert-danger">
                {{ session('error') }}
            </div>
        @endif

        <div class="my-4">
            <!-- Mostrar el userID y lastUpdate de la tabla Tokens -->
            @if ($tokens->count() > 0)
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Usuario sincronizado</th>
                            <th>Usuario de Fitbit</th>
                            <th>Última actualización de tokens</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($tokens as $token)
                            <tr>
                                <td>{{ $token->appUser }}</td>
                                <td>{{ $token->userID }}</td>
                                <td>{{ $token->lastUpdate }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            @else
                <p>No se encontraron tokens para el usuario actual.</p>
            @endif

            <!-- Aquí puedes agregar cualquier formulario o componente para gestionar la sincronización -->
            <!-- Ejemplo: Formulario para iniciar la sincronización -->
            <form action="{{ route('fitbit.sync.post') }}" method="POST">
                @csrf
                <button type="submit" class="btn btn-primary">Sincronizar con cuenta Fitbit</button>
            </form>
        </div>
    </div>
@push('styles')
<link href="{{ asset('css/fitbit_sync.css') }}" rel="stylesheet">
@endpush
@endsection
