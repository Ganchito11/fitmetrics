
@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">{{ __('Sincronización en proceso') }}</div>

                    <div class="card-body">
                        <p>{{ __('La sincronización con este usuario ya existía, los token de acceso han sido actualizados para él') }}</p>
                    </div>
                </div>
                <a href="{{ route('fitbit.redirectToSync') }}" class="btn btn-primary mt-3">{{ __('Volver a la pestaña de sincronización') }}</a>
            </div>
        </div>
    </div>
@endsection
