
@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">{{ __('Sincronización en proceso') }}</div>

                    <div class="card-body">
                        <p>{{ __('La sincronización está en proceso. Cuando hayas aceptado las condiciones y marcado todas las pestañas tu cuenta Fitbit estará sincronizada con fitmetrics.tech') }}</p>
                    </div>
                </div>
                <a href="{{ route('fitbit.redirectToSync') }}" class="btn btn-primary mt-3">{{ __('Volver a la pestaña de sincronización') }}</a>
            </div>
        </div>
    </div>
@endsection
