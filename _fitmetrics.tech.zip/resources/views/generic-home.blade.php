@extends('layouts.app')

@section('title', 'Generic Home')

@section('content')
    <div class="container mt-5">
        <div class="mb-5">
            <h1>Bienvenido(a) a FitMetrics</h1>
            <p>Por favor, inicia sesión o crea una cuenta para acceder a la funcionalidad completa del sitio.</p>
        </div>
        <div class="buttons">
            <a href="{{ route('login') }}" class="btn btn-primary">Iniciar sesión</a>
            <a href="{{ route('register') }}" class="btn btn-secondary">Crear cuenta</a>
        </div>
    </div>
    <div id="carouselExample" class="carousel slide mt-5" data-bs-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <a href="#" data-bs-toggle="modal" data-bs-target="#imageModal" data-image="{{ asset('images/Página_de_inicio.png') }}">
                    <img src="{{ asset('images/Página_de_inicio.png') }}" alt="Captura de pantalla 1">
                </a>
            </div>
            <div class="carousel-item">
                <a href="#" data-bs-toggle="modal" data-bs-target="#imageModal" data-image="{{ asset('images/Página_calorías_consumidas.png') }}">
                    <img src="{{ asset('images/Página_calorías_consumidas.png') }}" alt="Captura de pantalla 2">
                </a>
            </div>
            <div class="carousel-item">
                <a href="#" data-bs-toggle="modal" data-bs-target="#imageModal" data-image="{{ asset('images/Página_Dashboard.png') }}">
                    <img src="{{ asset('images/Página_Dashboard.png') }}" alt="Captura de pantalla 3">
                </a>
            </div>
            <div class="carousel-item">
                <a href="#" data-bs-toggle="modal" data-bs-target="#imageModal" data-image="{{ asset('images/Página_de_perfil_de_usuario.png') }}">
                    <img src="{{ asset('images/Página_de_perfil_de_usuario.png') }}" alt="Captura de pantalla 4">
                </a>
            </div>
            <div class="carousel-item">
                <a href="#" data-bs-toggle="modal" data-bs-target="#imageModal" data-image="{{ asset('images/Página_gráfico_ritmo_cardiaco.png') }}">
                    <img src="{{ asset('images/Página_gráfico_ritmo_cardiaco.png') }}" alt="Captura de pantalla 5">
                </a>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="imageModal" tabindex="-1" aria-labelledby="imageModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-xl">
            <div class="modal-content">
                <div class="modal-body text-center">
                    <img src="" alt="" id="modalImage" style="max-height: 80vh; max-width: 100%;">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('styles')
    <link href="{{ asset('css/generic_home.css') }}" rel="stylesheet">
@endpush

@push('scripts')
    <script>
        document.querySelectorAll('.carousel-item a').forEach(function(element) {
            element.addEventListener('click', function(event) {
                event.preventDefault();
                var imageSrc = this.dataset.image;
                document.getElementById('modalImage').src = imageSrc;
                var imageModal = new bootstrap.Modal(document.getElementById('imageModal'), {
                    backdrop: 'static',
                    keyboard: false
                });
                imageModal.show();
            });
        });

        var modal = document.getElementById('imageModal');
        modal.addEventListener('hidden.bs.modal', function() {
            document.body.classList.remove('modal-open');
            var backdrop = document.querySelector('.modal-backdrop');
            if (backdrop) {
                backdrop.parentNode.removeChild(backdrop);
            }
        });
    </script>
@endpush


