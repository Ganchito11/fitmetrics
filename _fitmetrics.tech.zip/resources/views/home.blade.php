@extends('layouts.app')

@section('title', 'Home')

@section('content')
    <div class="container">
        <h1>Bienvenido, {{ Auth::user()->name }}!</h1>

        <div class="col-12">
            <!-- Resumen de Datos Generales -->
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Resumen de Datos Generales del Día de Hoy</h5>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Usuario de Fitbit</th>
                                <th>Pasos</th>
                                <th>Plantas Subidas</th>
                                <th>Kilómetros Recorridos</th>
                                <th>Calorías Quemadas</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($datosGenerales as $datoGeneral)
                                <tr>
                                    <td>{{ $datoGeneral->encoded_id }}</td>
                                    <td>{{ $datoGeneral->pasos }}</td>
                                    <td>{{ $datoGeneral->plantas_subidas }}</td>
                                    <td>{{ $datoGeneral->kilometros_recorridos }}</td>
                                    <td>{{ $datoGeneral->calorias_quemadas }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

         <!-- Sincronización con cuenta Fitbit -->
         <div class="card mt-4">
            <div class="card-header">
                <h4>Sincronización con cuenta Fitbit</h4>
            </div>
            <div class="card-body">
            <form action="{{ route('fitbit.sync.post') }}" method="POST">
                @csrf
                <button type="submit" class="btn btn-primary">Clicka Aquí para Sincronizar tu cuenta Fitbit con FitMetrics</button>
            </form>
            </div>
        </div>


        <!-- Gráficas de datos -->
        <div class="card mt-4">
            <div class="card-header">
                <h4>Gráficas de datos de tu Actividad Diaria</h4>
            </div>
            <div class="card-body">
                @foreach ($formattedActiveMinutes as $encoded_id => $activityData)
                    <div class="chart-container">
                        <canvas id="chart-{{ $encoded_id }}" width="400" height="100"></canvas>
                    </div>
                @endforeach
            </div>
        </div>




    @push('scripts')
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <script>
            // Función para generar una gráfica de datos
            function generateChart(elementId, labels, data, encodedId) {
                var ctx = document.getElementById(elementId).getContext('2d');
                new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: labels,
                        datasets: [{
                            label: 'Minutos de actividad (Usuario de Fitbit: ' + encodedId + ')', // Agregar el encoded_id en la leyenda
                            data: data,
                            backgroundColor: 'rgba(54, 162, 235, 0.5)',
                            borderColor: 'rgba(54, 162, 235, 1)',
                            borderWidth: 1
                        }]
                    },
                    options: {
                        scales: {
                            y: {
                                beginAtZero: true,
                                title: {
                                    display: true,
                                    text: 'Minutos de actividad'
                                }
                            },
                            x: {
                                title: {
                                    display: true,
                                    text: 'Fecha'
                                }
                            }
                        }
                    }
                });
            }

            // Obtener los datos de actividad mensuales y generar las gráficas
            var formattedActiveMinutes = @json($formattedActiveMinutes);
            Object.keys(formattedActiveMinutes).forEach(function(encoded_id) {
                var elementId = 'chart-' + encoded_id;
                var labels = formattedActiveMinutes[encoded_id].dates;
                var activeMinutesData = formattedActiveMinutes[encoded_id].activeMinutes;
                generateChart(elementId, labels, activeMinutesData, encoded_id); // Pasar el encoded_id a la función
            });
        </script>

    @endpush
@endsection
