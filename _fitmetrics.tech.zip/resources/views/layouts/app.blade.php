<!DOCTYPE html>
<html lang="es">

@stack('styles')

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <!-- FontAwesome personal -->
    <script src="https://kit.fontawesome.com/06c6f7ab73.js" crossorigin="anonymous"></script>
    <!-- Titulo -->
    <title>@yield('title') - TFG FITBIT</title>
    <!-- Custom CSS -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link rel="icon" type="image/jpg" href="/favicon.ico" />
</head>

<body class="bg-light">
    <div class="wrapper d-flex flex-column min-vh-100">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="{{ route('home') }}"><i class="fas fa-home"></i> Inicio</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto">
                        @guest
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('login') }}"><i class="fas fa-user"></i> Login Usuario</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('register') }}"><i class="fas fa-user"></i> Crear Usuario</a>
                        </li>
                        @else
                        @if(auth()->user()->hasRole('admin'))
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('admin.dashboard') }}"><i class="fas fa-user"></i> Administración</a>
                        </li>
                        @endif
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('fitbit.showUserList') }}"><i class="fas fa-chart-bar"></i> Usuarios Fitbit Enlazados</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('fitbit-dashboard') }}"><i class="fas fa-columns"></i> Panel Fitbit</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('fitbit.redirectToSync') }}"><i class="fas fa-sync"></i> Sincronizar con Fitbit</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('user.dashboard') }}"><i class="fas fa-user"></i> Gestionar mi Cuenta</a>
                        </li>
                        <li class="nav-item">
                            <form action="{{ route('log-out') }}" method="POST" class="text-center">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-sign-out-alt"></i> Usuario {{ Auth::user()->name }}
                                </button>
                                @csrf
                            </form>
                        </li>
                        @endguest
                    </ul>
                </div>
            </div>
        </nav>

        <div class="content flex-grow-1">
            <main class="container mt-5">
                @yield('content')
            </main>
        </div>

        <footer class="footer">
            <div class="container-fluid">
                <div class="row justify-content-center">
                    <div class="col-12">
                        <div class="card text-center no-animation">
                            <div class="card-header">
                                Web de Integración de Servicios Fitbit
                            </div>
                            <div class="card-body">
                                <h5 class="card-title">TFG UNIVERSIDAD DE OVIEDO</h5>
                            </div>
                            <div class="card-footer text-muted">
                                Página elaborada por Francisco Javier de la Puente Secades
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </div>

    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <!-- Custom JavaScript -->
    <script src="{{ asset('js/app.js') }}"></script>
    <!-- Archivos CSS de Chart.js -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.css">
    <!-- Archivos JS de Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js"></script>


    @stack('scripts')
</body>

</html>
