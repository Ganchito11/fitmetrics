@extends('layouts.app')

@section('title', 'Gestión de usuario')

@section('content')
    <!-- Para eliminar el usuario al que está vinculado -->
    <div class="card mt-4">
        <div class="card-header text-center">
            <h4>Eliminar Usuario Vinculado</h4>
        </div>
        <div class="card-body p-4">
            <form id="userForm" method="POST" action="{{ route('user.deleteToken', ['encoded_id' => '__encoded_id__']) }}">
                @csrf
                @method('DELETE')
                <div class="input-group mb-3">
                    <label for="selectedUser" class="input-group-text">Selecciona un Usuario para Eliminar la Relación con esta Cuenta:</label>
                    <select name="selectedUser" id="selectedUser" class="form-select">
                        @foreach($tokens as $token)
                            <option value="{{ $token->userID }}" {{ (isset($selectedUser) && $selectedUser == $token->userID) ? 'selected' : '' }}>
                                {{ $token->userID }}
                            </option>
                        @endforeach
                    </select>
                    <div class="input-group-append">
                        <button type="submit" class="btn btn-primary">Eliminar</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Para cambiar el valor de refresh_enabled en la tabla de tokens -->
    <div class="card mt-4">
        <div class="card-header text-center">
            <h4>Habilitar refresco automático de los Token de Acceso</h4>
        </div>
        <div class="card-body p-4">
            <form id="refreshEnabledForm" action="{{ route('user.changeTokenValue', ['id' => Auth::user()->id]) }}" method="POST">
                @csrf
                @method('PUT') 
                <label class="form-check-label mb-2" for="refreshEnabled">Cambiar el valor del refresco automático</label>
                @foreach($tokens as $token)
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="refreshEnabled_{{ $token->userID }}" name="refreshEnabled[]" value="{{ $token->userID }}" {{ $token->refresh_enabled ? 'checked' : '' }}>
                        <label class="form-check-label" for="refreshEnabled_{{ $token->userID }}">{{ $token->userID }}</label>
                    </div>
                @endforeach
            </form>
        </div>
    </div>

    <!-- Para descargar la información del usuario -->
    <div class="card mt-4">
        <div class="card-header text-center">
            <h4>Descargar toda la información almacenada en FitMetrics de mi Usuario</h4>
        </div>
        <div class="card-body p-4 text-center">
            <a href="{{ route('user.downloadInfo', ['id' => Auth::id()]) }}" class="btn btn-info btn-block">Descargar mi información</a>
        </div>
    </div>

    <!-- Para borrar la cuenta del usuario -->
    <div class="card mt-4">
        <div class="card-header text-center">
            <h4>Eliminar Cuenta</h4>
        </div>
        <div class="card-body p-4 d-flex flex-column align-items-center">
            <form action="{{ route('user.delete', ['id' => Auth::id()]) }}" method="POST" class="text-center" id="deleteUserForm">
                @csrf
                @method('DELETE')
                <button type="submit" class="btn btn-danger" onclick="confirmDelete(event)">Eliminar mi cuenta</button>
            </form>
        </div>
    </div>

    <script>
        function confirmDelete(event) {
            event.preventDefault();

            if (confirm('¿Estás seguro de que deseas eliminar tu cuenta? Esta acción no se puede deshacer.')) {
                var password = prompt('Por favor, ingresa tu contraseña para confirmar la eliminación de tu cuenta.');

                if (password) {
                    var form = document.getElementById('deleteUserForm');
                    var passwordInput = document.createElement('input');
                    passwordInput.setAttribute('type', 'hidden');
                    passwordInput.setAttribute('name', 'password');
                    passwordInput.setAttribute('value', password);
                    form.appendChild(passwordInput);

                    form.submit();
                }
            }
        }
    </script>



    <script>
        // Script para enviar automáticamente el formulario cuando cambia una casilla de verificación
        var refreshEnabledForm = document.getElementById('refreshEnabledForm');
        var checkboxes = document.querySelectorAll('input[name="refreshEnabled[]"]');

        checkboxes.forEach(function(checkbox) {
            checkbox.addEventListener('change', function(event) {
                refreshEnabledForm.submit();
            });
        });
    </script>
@endsection
