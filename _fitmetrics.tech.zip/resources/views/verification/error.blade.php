<!DOCTYPE html>
<html>
<head>
    <title>Error de verificación</title>
</head>
<body>
    <h1>Error de verificación</h1>
    <p>El enlace de verificación es inválido o ha expirado. Por favor, intenta nuevamente o solicita un nuevo enlace de verificación.</p>
</body>
</html>

