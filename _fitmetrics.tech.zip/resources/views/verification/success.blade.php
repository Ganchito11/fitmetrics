@extends('layouts.app')

@section('title', 'Verificación exitosa')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-body text-center">
                        <h1 class="display-4 text-success">¡Verificación exitosa!</h1>
                        <p class="lead">Tu cuenta ha sido verificada correctamente. Ahora puedes disfrutar de todas las funcionalidades de nuestro servicio.</p>
                        <div class="mt-4">
                            <a href="{{ route('home') }}" class="btn btn-primary">Ir al inicio</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
