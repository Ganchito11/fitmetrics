<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ChartsController;
use App\Http\Controllers\ExcelController;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\SessionsController;
use App\Http\Controllers\FitbitSyncController;
use App\Http\Controllers\FitbitDataController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\UserController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Aquí es donde puedes registrar las rutas web para tu aplicación.
| Estas rutas son cargadas por el RouteServiceProvider dentro de un grupo que contiene el middleware "web".
|
*/

//Ruta de la página home
Route::get('/', [HomeController::class, 'index'])->name('home'); // Se muestra la vista "home" para usuarios autenticados

// Rutas de registro de usuarios
Route::get('/register', [RegisterController::class, 'create'])->name('register');
Route::post('/do-register', [RegisterController::class, 'store'])->name('do-register');

// Rutas de inicio de sesión
Route::get('/login', [SessionsController::class, 'login'])->name('login');
Route::post('/do-login', [SessionsController::class, 'doLogin'])->name('do-login');

// Ruta de cierre de sesión
Route::post('/logout', [SessionsController::class, 'logout'])->name('log-out')->middleware('auth');

// Rutas para roles de administrador
Route::group(['middleware' => ['role:admin']], function () {
    Route::get('/secret', function () {
        return view('auth.secret');
    })->name('auth.secret');
});

// Rutas para el envío de correo electrónico
Route::get('/email', [RegisterController::class, 'sendEmail'])->name('send-email');
Route::get('/email-sent', [RegisterController::class, 'showEmailSentView'])->name('email-sent');

// Ruta para verificar el correo electrónico
Route::get('/verify-email/{token}', [RegisterController::class, 'verifyEmail'])->name('verify-email');

// Página de éxito de verificación
Route::get('/verification-success', function () {
    return view('verification.success');
})->name('verification-success');

// Página de error de verificación
Route::get('/verification-error', function () {
    return view('verification.error');
})->name('verification-error');

// Ruta para mostrar la lista de usuarios de Fitbit
Route::middleware('auth')->group(function () {
    Route::get('fitbit/users', [FitbitDataController::class, 'showUserList'])->name('fitbit.showUserList');
    Route::get('fitbit/users/{encoded_id}', [FitbitDataController::class, 'showUserInfo'])->name('fitbit.showUserInfo');
});

// Ruta para sincronizar Fitbit
Route::middleware('auth')->group(function () {
    Route::get('/fitbit/sync', [FitbitSyncController::class, 'redirectToSync'])->name('fitbit.redirectToSync');
    Route::post('/fitbit/sync', [FitbitSyncController::class, 'sync'])->name('fitbit.sync.post');
    Route::get('/fitbit/oauth2-callback', [FitbitSyncController::class, 'handleAuthorizationCallback'])->name('fitbit.handleAuthorizationCallback');
});

// Información de salud de Fitbit
Route::middleware('auth')->group(function () {
    Route::get('/fitbit-dashboard', [FitbitDataController::class, 'showFitbitDashboard'])->name('fitbit-dashboard');
    Route::get('/fitbit/calories', [FitbitDataController::class, 'showCalories'])->name('fitbit.calories');
    Route::get('/fitbit/calories/{encoded_id?}', [FitbitDataController::class, 'showCalories'])->name('fitbit.showCalories');
    Route::get('/fitbit/steps', [FitbitDataController::class, 'showSteps'])->name('fitbit.steps');
    Route::get('/fitbit/steps/{encoded_id?}', [FitbitDataController::class, 'showSteps'])->name('fitbit.showSteps');
    Route::get('/fitbit/heart_zones', [FitbitDataController::class, 'showHeartRateZones'])->name('fitbit.heart_zones');
    Route::get('/fitbit/heart_zones/{encoded_id?}', [FitbitDataController::class, 'showHeartRateZones'])->name('fitbit.showHeartRateZones');
    Route::post('/fitbit/generate-data', [FitbitDataController::class, 'generateData'])->name('fitbit.generateData');
    Route::get('/fitbit/sleep', [FitbitDataController::class, 'showSleep'])->name('fitbit.sleep');
    

});

//Ruta de gestión de cuenta
Route::middleware('auth')->group(function () {
    Route::get('/user/dashboard', [UserController::class, 'dashboard'])->name('user.dashboard');
    Route::delete('/user/delete-token/{encoded_id}', [UserController::class, 'deleteUserToken'])->name('user.deleteToken');
    Route::put('/user/{id}/change-token-value', [UserController::class, 'changeTokenValue'])->name('user.changeTokenValue');
    Route::get('/user/{id}/download-info', [UserController::class, 'downloadUserInfo'])->name('user.downloadInfo');
    Route::delete('/user/{id}', [UserController::class, 'deleteUser'])->name('user.delete');
});

Route::get('/server-info', function () {
    $serverSoftware = $_SERVER['SERVER_SOFTWARE'];
    return "Servidor web en uso: " . $serverSoftware;
});
