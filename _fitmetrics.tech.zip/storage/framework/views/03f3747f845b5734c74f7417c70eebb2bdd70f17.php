<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Sincronización en proceso')); ?></div>

                    <div class="card-body">
                        <p><?php echo e(__('La sincronización está en proceso. Cuando hayas aceptado las condiciones y marcado todas las pestañas tu cuenta Fitbit estará sincronizada con fitmetrics.tech')); ?></p>
                    </div>
                </div>
                <a href="<?php echo e(route('fitbit.redirectToSync')); ?>" class="btn btn-primary mt-3"><?php echo e(__('Volver a la pestaña de sincronización')); ?></a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u401132006/domains/fitmetrics.tech/resources/views/fitbit_sync/sync_in_progress.blade.php ENDPATH**/ ?>