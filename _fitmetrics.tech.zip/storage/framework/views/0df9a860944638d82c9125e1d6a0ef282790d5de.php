<?php $__env->startSection('title','Create'); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .bg-light-blue {
            background-color: #87CEFA;
            border: 3px solid blue;
            width: 300px;
            height: 40px;
        }

    </style>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('products.store')); ?>" method="POST" class="text-center">
        <?php echo csrf_field(); ?>
        <h2> Crear Productos</h2>
        <input type="text" class="bg-light-blue text-center" placeholder="Title" name="title">
        <input type="text" class="bg-light-blue text-center" placeholder="Country" name="country">
        <input type="number" class="bg-light-blue text-center" placeholder="Price" name="price">
        <!--"
        <select type="select"  name="user_id" class="bg-light-blue text-center">
            <?php $__currentLoopData = \App\Models\User::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value = "<?php echo e($user->id); ?>"  >     <?php echo e($user->name); ?>    </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        "-->
        <button type="submit" class="btn btn-primary" > SEND</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/crud/resources/views/products/create.blade.php ENDPATH**/ ?>