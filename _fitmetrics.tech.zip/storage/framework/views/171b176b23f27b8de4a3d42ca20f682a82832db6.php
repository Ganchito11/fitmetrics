<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Gráfico de Calorías Quemadas</h1>
    

    <?php if($UserFitbitInfo->isNotEmpty()): ?>
        <form id="userForm" method="get" action="<?php echo e(route('fitbit.showCalories', ['encoded_id' => '__encoded_id__'])); ?>" class="mb-3">
            <div class="input-group">
                <label for="selectedUser" class="input-group-text">Selecciona un Usuario:</label>
                <select name="selectedUser" id="selectedUser" class="form-select">
                    <?php $__currentLoopData = $UserFitbitInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($datos->encoded_id); ?>" <?php echo e((isset($selectedUser) && $selectedUser == $datos->encoded_id) ? 'selected' : ''); ?>>
                            <?php echo e($datos->encoded_id); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button type="submit" class="btn btn-primary">Obtener información del usuario</button>
            </div>
        </form>
    <?php endif; ?>

    <div class="card">
        <div class="card-body" style="height: 700px;"> <!-- Ajusta la altura del contenedor del gráfico -->
            <canvas id="caloriesChart"></canvas>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script>
    var form = document.getElementById('userForm');
    form.addEventListener('submit', function(event) {
        var selectedUser = document.getElementById('selectedUser').value;
        form.action = form.action.replace('__encoded_id__', selectedUser);
        event.preventDefault();
        window.location.href = form.action;
    });
</script>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        var caloriesData = <?php echo json_encode($caloriesData, 15, 512) ?>; // Convertir los datos de PHP a JSON
        
        // Ordenar los datos en orden cronológico
        caloriesData.sort(function(a, b) {
            return new Date(a.date) - new Date(b.date);
        });
        
        var dates = caloriesData.map(function(data) {
            return data.date;
        });
        
        var calories = caloriesData.map(function(data) {
            return data.calories_out; // Corregir el acceso a la propiedad 'calories_out'
        });
        
        // Configurar el gráfico
        var ctx = document.getElementById("caloriesChart").getContext("2d");
        var chart = new Chart(ctx, {
            type: "line",
            data: {
                labels: dates,
                datasets: [{
                    label: "Calorias Consumidas",
                    data: calories,
                    backgroundColor: "rgba(75, 192, 192, 0.2)",
                    borderColor: "rgba(75, 192, 192, 1)",
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: {
                        type: "time",
                        time: {
                            unit: "day"
                        }
                    },
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u401132006/domains/fitmetrics.tech/resources/views/fitbit/calories.blade.php ENDPATH**/ ?>