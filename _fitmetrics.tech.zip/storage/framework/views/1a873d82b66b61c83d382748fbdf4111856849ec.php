<?php $__env->startSection('title', 'Verificación exitosa'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-body text-center">
                        <h1 class="display-4 text-success">¡Verificación exitosa!</h1>
                        <p class="lead">Tu cuenta ha sido verificada correctamente. Ahora puedes disfrutar de todas las funcionalidades de nuestro servicio.</p>
                        <div class="mt-4">
                            <a href="<?php echo e(route('home')); ?>" class="btn btn-primary">Ir al inicio</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u401132006/domains/fitmetrics.tech/resources/views/verification/success.blade.php ENDPATH**/ ?>