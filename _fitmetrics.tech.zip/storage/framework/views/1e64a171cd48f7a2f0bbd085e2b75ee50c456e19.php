<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="mb-4">Sincronización con Fitbit</h1>

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <div class="my-4">
            <!-- Mostrar el userID y lastUpdate de la tabla Tokens -->
            <?php if($tokens->count() > 0): ?>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Usuario sincronizado</th>
                            <th>Usuario de Fitbit</th>
                            <th>Última actualización de tokens</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $tokens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $token): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($token->appUser); ?></td>
                                <td><?php echo e($token->userID); ?></td>
                                <td><?php echo e($token->lastUpdate); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No se encontraron tokens para el usuario actual.</p>
            <?php endif; ?>

            <!-- Aquí puedes agregar cualquier formulario o componente para gestionar la sincronización -->
            <!-- Ejemplo: Formulario para iniciar la sincronización -->
            <form action="<?php echo e(route('fitbit.sync.post')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-primary">Sincronizar con cuenta Fitbit</button>
            </form>
        </div>
    </div>
<?php $__env->startPush('styles'); ?>
<link href="<?php echo e(asset('css/fitbit_sync.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/crud/resources/views/fitbit_sync/fitbit_sync.blade.php ENDPATH**/ ?>