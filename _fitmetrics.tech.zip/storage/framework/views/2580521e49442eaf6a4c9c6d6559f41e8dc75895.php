<?php $__env->startComponent('mail::message'); ?>
# Welcome to verification e-mail

Tienes que verificar el correo electrónico para funcionar con el servicio CRUD.
Por favor, haz clic en el siguiente botón para validar tu cuenta:

<?php $__env->startComponent('mail::button', ['url' => route('verify-email', ['token' => $user->email_verification_token])]); ?>
Validate User
<?php echo $__env->renderComponent(); ?>

Gracias por tu tiempo.
<?php echo $__env->renderComponent(); ?>

<?php /**PATH /var/www/html/crud/resources/views/emails/welcome.blade.php ENDPATH**/ ?>