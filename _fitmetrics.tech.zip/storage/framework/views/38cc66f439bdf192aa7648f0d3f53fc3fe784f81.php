<?php $__env->startComponent('mail::message'); ?>
# E-mail de Verificación de Bienvenida

Tienes que verificar el correo electrónico para funcionar con el servicio CRUD de FitMetrics.
Por favor, haz clic en el siguiente botón para validar tu cuenta:

<?php $__env->startComponent('mail::button', ['url' => route('verify-email', ['token' => $user->email_verification_token])]); ?>
Validar Correo Electrónico
<?php echo $__env->renderComponent(); ?>

Gracias por tu tiempo.
<?php echo $__env->renderComponent(); ?>

<?php /**PATH /home/u401132006/domains/fitmetrics.tech/resources/views/emails/welcome.blade.php ENDPATH**/ ?>