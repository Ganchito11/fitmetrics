<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Gráfico de Sueño</h1>

    <?php if($userFitbitInfo->isNotEmpty()): ?>
        <form id="userForm" method="get" action="<?php echo e(route('fitbit.sleep')); ?>" class="mb-3">
            <div class="input-group">
                <label for="selectedUser" class="input-group-text">Selecciona un Usuario:</label>
                <select name="selectedUser" id="selectedUser" class="form-select">
                    <?php $__currentLoopData = $userFitbitInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($datos->user_id); ?>" <?php echo e((isset($selectedUser) && $selectedUser == $datos->user_id) ? 'selected' : ''); ?>>
                            <?php echo e($datos->user_id); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button type="button" class="btn btn-primary" id="getStartTimesBtn">Seleccionar usuario</button>
            </div>
            <div class="input-group mt-3">
                <label for="startTime" class="input-group-text">Selecciona una Fecha de Inicio:</label>
                <select name="startTime" id="startTime" class="form-select">
                    <?php $__currentLoopData = $startTimes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $startTime): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($startTime); ?>" <?php echo e((isset($selectedStartTime) && $selectedStartTime == $startTime) ? 'selected' : ''); ?>>
                            <?php echo e($startTime); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button type="submit" class="btn btn-primary">Obtener información del usuario</button>
            </div>
        </form>
    <?php endif; ?>

    <div id="sleepSessionsContainer" class="row">
        <?php $__currentLoopData = $sleepSessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $startDateTime = \Carbon\Carbon::parse($session->start_time);
                $endDateTime = \Carbon\Carbon::parse($session->end_time);
                $formattedStartTime = $startDateTime->format('h:i A'); // Formato de hora: 12 horas con AM/PM
                $formattedEndTime = $endDateTime->format('h:i A'); // Formato de hora: 12 horas con AM/PM

                $data = json_decode($session->data, true); // Convertir la cadena JSON en un arreglo
                $summary = json_decode($session->summary, true); // Convertir la cadena JSON en un arreglo
            ?>

            <div class="col-md-12">
                <div class="card mb-4">
                    <div class="card-body text-center">
                        <h3 class="text-center">Sesión de Sueño: <?php echo e($session->date); ?></h3>
                        <p class="interval-time">
                            <strong>Inicio: </strong><?php echo e($formattedStartTime); ?>

                            <span style="margin-left: 50px; margin-right: 20px;"></span>
                            <strong>Fin: </strong><?php echo e($formattedEndTime); ?>

                        </p>
                    </div>
                </div>
            </div>

            <div class="col-md-12">
                <div class="card mb-4">
                    <div class="card-body text-center">
                        <div class="card-body">
                            <h4>Horas de sueño en las distintas fases</h4>
                            <canvas id="levelChart_<?php echo e($session->id); ?>" width="400" height="200"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-7">
                <div class="card mb-4">
                    <div class="card-body text-center">
                        <div class="card-body">
                            <h4>Tiempo cada etapa</h4>
                            <canvas id="stageChart_<?php echo e($session->id); ?>" width="400" height="320"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-5">
                <div class="card mb-4">
                    <div class="card-body">
                        <h4>Resumen:</h4>
                        <ul>
                            <?php $__currentLoopData = $summary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stage => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $translatedStage = '';
                                    if ($stage === 'light') {
                                        $translatedStage = 'Fase de Sueño Ligero';
                                    } elseif ($stage === 'wake') {
                                        $translatedStage = 'Despierto';
                                    } elseif ($stage === 'deep') {
                                        $translatedStage = 'Fase de Sueño Profundo';
                                    } elseif ($stage === 'rem') {
                                        $translatedStage = 'Fase Rem';
                                    } elseif ($stage === 'awake') {
                                        $translatedStage = 'Despierto';
                                    } elseif ($stage === 'asleep') {
                                        $translatedStage = 'Dormido';
                                    } elseif ($stage === 'restless') {
                                        $translatedStage = 'Inquieto';
                                    }
                                ?>
                                <li>
                                    <?php echo e(ucfirst($translatedStage)); ?>:
                                    <ul>
                                        <li>Veces que se entró en esta fase: <?php echo e($details['count']); ?> veces</li>
                                        <li>Minutos en esta fase: <?php echo e($details['minutes']); ?> min</li>
                                        <?php if(isset($details['thirtyDayAvgMinutes'])): ?>
                                            <li>Promedio en los últimos 30 días en esta fase: <?php echo e($details['thirtyDayAvgMinutes']); ?> min</li>
                                        <?php endif; ?>
                                    </ul>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
<script>
    document.getElementById('getStartTimesBtn').addEventListener('click', function(event) {
        var selectedUserId = document.getElementById('selectedUser').value;
        var startTime = document.getElementById('startTime').value;
        var actionUrl = "<?php echo e(route('fitbit.sleep')); ?>?selectedUser=" + selectedUserId + "&startTime=" + startTime;
        window.location.href = actionUrl;
    });

    document.getElementById('userForm').addEventListener('submit', function(event) {
        var selectedUserId = document.getElementById('selectedUser').value;
        var startTime = document.getElementById('startTime').value;
        var actionUrl = "<?php echo e(route('fitbit.sleep')); ?>?selectedUser=" + selectedUserId + "&startTime=" + startTime;
        this.action = actionUrl;
    });
</script>
<?php $__currentLoopData = $sleepSessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <script>
        var sessionData_<?php echo e($session->id); ?> = <?php echo $session->data; ?>;
        var levelData_<?php echo e($session->id); ?> = sessionData_<?php echo e($session->id); ?>.map(data => Math.round(data.seconds / 60));
        var levelLabels_<?php echo e($session->id); ?> = sessionData_<?php echo e($session->id); ?>.map(data => moment(data.dateTime).format('HH:mm'));

        var levelChart_<?php echo e($session->id); ?> = new Chart(document.getElementById('levelChart_<?php echo e($session->id); ?>'), {
            type: 'bar',
            data: {
                labels: levelLabels_<?php echo e($session->id); ?>,
                datasets: [
                    {
                        label: 'Minutos de sueño en esta fase',
                        data: levelData_<?php echo e($session->id); ?>,
                        backgroundColor: 'rgba(54, 162, 235, 0.2)',
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 1
                    },
                ]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value, index, values) {
                                return value + ' min';
                            }
                        }
                    }
                },
                tooltips: {
                    enabled: true,
                    mode: 'single',
                    callbacks: {
                        label: function(tooltipItem, data) {
                            var levelInfo = sessionData_<?php echo e($session->id); ?>[tooltipItem.index].level;
                            var minutes = levelData_<?php echo e($session->id); ?>[tooltipItem.index];

                            if (levelInfo === 'light') {
                                levelInfo = 'Ligero';
                            } else if (levelInfo === 'wake') {
                                levelInfo = 'Despierto';
                            } else if (levelInfo === 'deep') {
                                levelInfo = 'Profundo';
                            } else if (levelInfo === 'awake') {
                                levelInfo = 'Despierto';
                            } else if (levelInfo === 'asleep') {
                                levelInfo = 'Dormido';
                            } else if (levelInfo === 'restless') {
                                levelInfo = 'Inquieto';
                            }

                            return 'Fase: ' + levelInfo + ', Minutos: ' + minutes;
                        }
                    }
                }
            }
        });



        var stageData_<?php echo e($session->id); ?> = <?php echo $session->summary; ?>;
        var stageLabels_<?php echo e($session->id); ?> = Object.keys(stageData_<?php echo e($session->id); ?>);
        var stageMinutes_<?php echo e($session->id); ?> = Object.values(stageData_<?php echo e($session->id); ?>).map(value => value.minutes);

        var translatedStageLabels_<?php echo e($session->id); ?> = stageLabels_<?php echo e($session->id); ?>.map(function(stage) {
        if (stage === 'light') {
            return 'Sueño Ligero';
        } else if (stage === 'wake') {
            return 'Despierto';
        } else if (stage === 'deep') {
            return 'Sueño Profundo';
        } else if (stage === 'rem') {
            return 'Rem';
        } else if (stage === 'awake') {
            return 'Despierto';
        } else if (stage === 'asleep') {
            return 'Dormido';
        } else if (stage === 'restless') {
            return 'Inquieto';
        }
    });

        var stageChart_<?php echo e($session->id); ?> = new Chart(document.getElementById('stageChart_<?php echo e($session->id); ?>'), {
            type: 'bar',
            data: {
                labels: translatedStageLabels_<?php echo e($session->id); ?>,
                datasets: [{
                    label: 'Minutos en cada etapa',
                    data: stageMinutes_<?php echo e($session->id); ?>,
                    backgroundColor: 'rgba(255, 99, 132, 0.2)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value, index, values) {
                                return value + ' min';
                            }
                        }
                    }
                }
            }
        });
    </script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u401132006/domains/fitmetrics.tech/resources/views/fitbit/sleep.blade.php ENDPATH**/ ?>