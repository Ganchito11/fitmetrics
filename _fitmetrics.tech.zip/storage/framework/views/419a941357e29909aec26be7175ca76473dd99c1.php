<?php echo e($slot); ?>

<?php /**PATH /home/u401132006/domains/fitmetrics.tech/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>