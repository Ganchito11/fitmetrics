<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <?php if($errors->has('message')): ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo e($errors->first('message')); ?>

                    </div>
                <?php else: ?>
                    <div class="card">
                        <div class="card-header">Email Sent</div>
                        <div class="card-body">
                            <p>Email verification has been sent to your email address.</p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/crud/resources/views/emails/email-sent.blade.php ENDPATH**/ ?>