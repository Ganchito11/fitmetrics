<?php $__env->startSection('content'); ?>
<div class="container" style="height: 900px;">
    <h1>Gráfico de Zonas de Ritmo Cardiaco</h1>

    <?php if($UserFitbitInfo->isNotEmpty()): ?>
        <form id="userForm" method="get" action="<?php echo e(route('fitbit.showHeartRateZones', ['encoded_id' => '__encoded_id__'])); ?>" class="mb-3">
            <div class="input-group">
                <label for="selectedUser" class="input-group-text">Selecciona un Usuario:</label>
                <select name="selectedUser" id="selectedUser" class="form-select">
                    <?php $__currentLoopData = $UserFitbitInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($datos->encoded_id); ?>" <?php echo e((isset($selectedUser) && $selectedUser == $datos->encoded_id) ? 'selected' : ''); ?>>
                            <?php echo e($datos->encoded_id); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button type="submit" class="btn btn-primary">Obtener información del usuario</button>
            </div>
        </form>
    <?php endif; ?>

    <div class="card" style="width: 150%; margin-left: -25%;">
        <div class="card-body">
            <div class="chart-container" style="position: relative; height: 600px; width: 100%; max-width: 2000px; margin: 0 auto; ">
                <canvas id="heartRateZonesChart"></canvas>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script>
    var form = document.getElementById('userForm');
    form.addEventListener('submit', function(event) {
        var selectedUser = document.getElementById('selectedUser').value;
        form.action = form.action.replace('__encoded_id__', selectedUser);
        event.preventDefault();
        window.location.href = form.action;
    });

</script>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        var heartRateZonesData = <?php echo json_encode($heartRateZonesData, 15, 512) ?>;

        // Ordenar los datos en orden cronológico
        heartRateZonesData.sort(function(a, b) {
            return new Date(a.date) - new Date(b.date);
        });

        var dates = heartRateZonesData.map(function(data) {
            return new Date(data.date);
        });

        var zoneLabels = ['Por debajo del Rango de Actividad', 'Quema de Grasas', 'Cardio', 'Pico de Pulsaciones'];
        var zoneColors = ['rgba(75, 192, 192, 0.5)', 'rgba(255, 99, 132, 0.5)', 'rgba(54, 162, 235, 0.5)', 'rgba(255, 206, 86, 0.5)']; // Colores más iluminados

        var zoneData = heartRateZonesData.map(function(data) {
            if (data.heart_rate_zones === null) {
                return [0, 0, 0, 0];  // si es null, devolver un arreglo de ceros
            }
            return data.heart_rate_zones.map(function(zone) {
                return zone.minutes || 0;  // si zone.minutes es null, devolver cero
            });
        });

        // Verificar si los datos son un arreglo vacío y tomar la acción correspondiente
        if (zoneData.every(function(data) { return data.length === 0; })) {
            // Mostrar un mensaje o realizar alguna otra acción para indicar que no hay datos disponibles
            // Por ejemplo, podrías mostrar un mensaje en el lugar del gráfico o deshabilitar el gráfico
            console.log("No hay datos disponibles para las zonas de ritmo cardíaco.");
            return;
        }

        // Configurar el gráfico
        var ctx = document.getElementById("heartRateZonesChart").getContext("2d");
        var chart = new Chart(ctx, {
            type: "bar",
            data: {
                labels: dates,
                datasets: zoneLabels.map(function(label, index) {
                    return {
                        label: label,
                        data: zoneData.map(function(data) {
                            return data[index];
                        }),
                        backgroundColor: zoneColors[index],
                        borderColor: zoneColors[index],
                        borderWidth: 1
                    };
                })
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: {
                        type: "time",
                        time: {
                            parser: 'yyyy-MM-dd',
                            unit: "day"
                        }
                    },
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Minutos'
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            title: function(context) {
                                var dataIndex = context[0].dataIndex;
                                var zone = heartRateZonesData[dataIndex];
                                return zone.name;
                            },
                            label: function(context) {
                                var datasetIndex = context.datasetIndex;
                                var dataIndex = context.dataIndex;
                                var zone = heartRateZonesData[dataIndex].heart_rate_zones[datasetIndex];
                                return 'Minutos en esta zona: ' + zone.minutes + '   ///   El Rango de Pulsaciones Configurado: ' + zone.min + '-' + zone.max;
                            }
                        }
                    }
                }
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u401132006/domains/fitmetrics.tech/resources/views/fitbit/heart_zones.blade.php ENDPATH**/ ?>