<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Fitbit Dashboard</h1>

        <div class="row">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-running"></i> Actividad Física</h5>
                        <p class="card-text">Ver información relacionada con tu actividad física.</p>
                        <a href="<?php echo e(route('fitbit.activity')); ?>" class="btn btn-primary">Ver Actividad Física</a>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-heartbeat"></i> Ritmo Cardíaco</h5>
                        <p class="card-text">Ver información relacionada con tu ritmo cardíaco.</p>
                        <a href="<?php echo e(route('fitbit.heart-rate')); ?>" class="btn btn-primary">Ver Ritmo Cardíaco</a>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-bed"></i> Sueño</h5>
                        <p class="card-text">Ver información relacionada con tu sueño.</p>
                        <a href="<?php echo e(route('fitbit.sleep')); ?>" class="btn btn-primary">Ver Sueño</a>
                    </div>
                </div>
            </div>

            <div class="col-12">
                <!-- Resumen de Datos Generales -->
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Resumen de Datos Generales</h5>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Encoded ID</th>
                                    <th>Pasos</th>
                                    <th>Plantas Subidas</th>
                                    <th>Kilómetros Recorridos</th>
                                    <th>Calorías Quemadas</th>
                                    <th>Fecha de Creación</th>
                                    <th>Fecha de Actualización</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $datosGenerales ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datoGeneral): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($datoGeneral->encoded_id); ?></td>
                                    <td><?php echo e($datoGeneral->pasos); ?></td>
                                    <td><?php echo e($datoGeneral->plantas_subidas); ?></td>
                                    <td><?php echo e($datoGeneral->kilometros_recorridos); ?></td>
                                    <td><?php echo e($datoGeneral->calorias_quemadas); ?></td>
                                    <td><?php echo e($datoGeneral->created_at); ?></td>
                                    <td><?php echo e($datoGeneral->updated_at); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link href="<?php echo e(asset('css/fitbit-dashboard.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/crud/resources/views/fitbit/fitbit-dashboard.blade.php ENDPATH**/ ?>