<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/u401132006/domains/fitmetrics.tech/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>