<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Bienvenido, <?php echo e(Auth::user()->name); ?>!</h1>

        <div class="col-12">
            <!-- Resumen de Datos Generales -->
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Resumen de Datos Generales del Día de Hoy</h5>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Usuario de Fitbit</th>
                                <th>Pasos</th>
                                <th>Plantas Subidas</th>
                                <th>Kilómetros Recorridos</th>
                                <th>Calorías Quemadas</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $datosGenerales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datoGeneral): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($datoGeneral->encoded_id); ?></td>
                                    <td><?php echo e($datoGeneral->pasos); ?></td>
                                    <td><?php echo e($datoGeneral->plantas_subidas); ?></td>
                                    <td><?php echo e($datoGeneral->kilometros_recorridos); ?></td>
                                    <td><?php echo e($datoGeneral->calorias_quemadas); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

         <!-- Sincronización con cuenta Fitbit -->
         <div class="card mt-4">
            <div class="card-header">
                <h4>Sincronización con cuenta Fitbit</h4>
            </div>
            <div class="card-body">
            <form action="<?php echo e(route('fitbit.sync.post')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-primary">Clicka Aquí para Sincronizar tu cuenta Fitbit con FitMetrics</button>
            </form>
            </div>
        </div>


        <!-- Gráficas de datos -->
        <div class="card mt-4">
            <div class="card-header">
                <h4>Gráficas de datos de tu Actividad Diaria</h4>
            </div>
            <div class="card-body">
                <?php $__currentLoopData = $formattedActiveMinutes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encoded_id => $activityData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="chart-container">
                        <canvas id="chart-<?php echo e($encoded_id); ?>" width="400" height="100"></canvas>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>




    <?php $__env->startPush('scripts'); ?>
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <script>
            // Función para generar una gráfica de datos
            function generateChart(elementId, labels, data, encodedId) {
                var ctx = document.getElementById(elementId).getContext('2d');
                new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: labels,
                        datasets: [{
                            label: 'Minutos de actividad (Usuario de Fitbit: ' + encodedId + ')', // Agregar el encoded_id en la leyenda
                            data: data,
                            backgroundColor: 'rgba(54, 162, 235, 0.5)',
                            borderColor: 'rgba(54, 162, 235, 1)',
                            borderWidth: 1
                        }]
                    },
                    options: {
                        scales: {
                            y: {
                                beginAtZero: true,
                                title: {
                                    display: true,
                                    text: 'Minutos de actividad'
                                }
                            },
                            x: {
                                title: {
                                    display: true,
                                    text: 'Fecha'
                                }
                            }
                        }
                    }
                });
            }

            // Obtener los datos de actividad mensuales y generar las gráficas
            var formattedActiveMinutes = <?php echo json_encode($formattedActiveMinutes, 15, 512) ?>;
            Object.keys(formattedActiveMinutes).forEach(function(encoded_id) {
                var elementId = 'chart-' + encoded_id;
                var labels = formattedActiveMinutes[encoded_id].dates;
                var activeMinutesData = formattedActiveMinutes[encoded_id].activeMinutes;
                generateChart(elementId, labels, activeMinutesData, encoded_id); // Pasar el encoded_id a la función
            });
        </script>

    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u401132006/domains/fitmetrics.tech/resources/views/home.blade.php ENDPATH**/ ?>