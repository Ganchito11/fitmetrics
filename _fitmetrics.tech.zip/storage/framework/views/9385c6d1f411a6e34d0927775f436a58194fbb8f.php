<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <?php if($errors->has('message')): ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo e($errors->first('message')); ?>

                    </div>
                <?php else: ?>
                    <div class="card">
                        <div class="card-header">Correo Electrónico enviado</div>
                        <div class="card-body">
                            <p>El Email de verificación ha sido enviado al correo indicado.</p>
                            <p>Por favor, revise su bandeja de entrada.</p>
                            <p>Si no ha recibido el correo electrónico, por favor, vuelva a registrarse.</p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        $("#resend-link").on('click', function(e) {
            e.preventDefault(); // Prevenir la acción por defecto del enlace

            $.ajax({
                url: "<?php echo e(route('send-email', ['email' => $email])); ?>",
                type: 'GET',
                success: function() {
                    alert("Email reenviado con éxito");
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    alert("Hubo un error al reenviar el email: " + jqXHR.responseText);
                }
            });
        });
    });
</script>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u401132006/domains/fitmetrics.tech/resources/views/emails/email-sent.blade.php ENDPATH**/ ?>