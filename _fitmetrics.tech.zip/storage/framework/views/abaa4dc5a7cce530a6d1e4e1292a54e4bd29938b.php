<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome personal -->
    <script src="https://kit.fontawesome.com/06c6f7ab73.js" crossorigin="anonymous"></script>
    <!-- Titulo -->
    <title><?php echo $__env->yieldContent('title'); ?> - TFG FITBIT</title>
    <!-- Custom CSS -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>

<body class="bg-light">
    <div class="wrapper">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="<?php echo e(route('home')); ?>"><i class="fa-sharp fa-solid fa-house"></i> Inicio</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto">
                        <?php if(auth()->guard()->check()): ?>
                            <?php if(auth()->user()->hasRole('admin')): ?>
                                <li class="nav-item">
                                    <a class="nav-link active" aria-current="page" href="<?php echo e(route('auth.secret')); ?>"><i class="fa-sharp fa-solid fa-user"></i> Private</a>
                                </li>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a class="nav-link active" aria-current="page" href="<?php echo e(route('login')); ?>"><i class="fa-sharp fa-solid fa-user"></i> Login Usuario</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" aria-current="page" href="<?php echo e(route('register')); ?>"><i class="fa-sharp fa-solid fa-user"></i> Crear Usuario</a>
                            </li>
                        <?php else: ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('charts.sales')); ?>"><i class="fas fa-chart-bar"></i> Ventas</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('charts.income')); ?>"><i class="fas fa-chart-pie"></i> Ingresos</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('charts.expenses')); ?>"><i class="fas fa-chart-line"></i> Gastos</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('fitbit.redirectToSync')); ?>"><i class="fas fa-sync"></i> Sincronizar con Fitbit</a>
                            </li>
                        <?php endif; ?>

                        <?php if(auth()->guard()->check()): ?>
                            <form action="<?php echo e(route('log-out')); ?>" method="POST" class="text-center">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa-solid fa-right-from-bracket"></i> Usuario <?php echo e(Auth::user()->name); ?>

                                </button>
                                <?php echo csrf_field(); ?>
                            </form>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <div class="content">
            <main class="container mt-5">
                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </div>

        <footer class="footer">
            <div class="card text-center">
                <div class="card-header">
                    CRUD
                </div>
                <div class="card-body">
                    <h5 class="card-title">TFG_FITBIT</h5>
                </div>
                <div class="card-footer text-muted">
                    2023
                </div>
            </div>
        </footer>
    </div>

    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom JavaScript -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>

</html>

<?php /**PATH /var/www/html/crud/resources/views/layout/app.blade.php ENDPATH**/ ?>