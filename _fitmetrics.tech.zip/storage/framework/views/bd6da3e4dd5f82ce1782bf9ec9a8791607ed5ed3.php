<?php $__env->startSection('head'); ?>
    <link href="<?php echo e(asset('css/fitbit_users.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if($UserFitbitInfo->isNotEmpty()): ?>
            <form id="userForm" method="post" action="<?php echo e(route('fitbit.showUserInfo', ['encoded_id' => '__encoded_id__'])); ?>" class="mb-3">
                <?php echo csrf_field(); ?>
                <div class="input-group">
                    <label for="selectedUser" class="input-group-text">Selecciona un Usuario:</label>
                    <select name="selectedUser" id="selectedUser" class="form-select">
                        <?php $__currentLoopData = $UserFitbitInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($datos->encoded_id); ?>" <?php echo e((isset($selectedUser) && $selectedUser == $datos->encoded_id) ? 'selected' : ''); ?>>
                                <?php echo e($datos->encoded_id); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <button type="submit" class="btn btn-primary">Obtener información del usuario</button>
                </div>
            </form>
        <?php endif; ?>

        <?php if(isset($selectedUser)): ?>
            <?php $__currentLoopData = $UserFitbitInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($datos->encoded_id == $selectedUser): ?>
                    <div class="card">
                        <div class="row g-0">
                            <div class="col-md-4">
                                <img src="<?php echo e($datos->avatar); ?>" class="img-fluid avatar-image" alt="AVATAR DE FITBIT">
                            </div>
                            <div class="col-md-8">
                                <div class="card-body">
                                    <h1 class="card-title"><?php echo e($datos->full_name); ?></h1>
                                    <p class="card-text">Age: <?php echo e($datos->age); ?></p>
                                    <p class="card-text">Gender: <?php echo e($datos->gender); ?></p>
                                    <p class="card-text">Height: <?php echo e($datos->height); ?> cm</p>
                                    <p class="card-text">Weight: <?php echo e($datos->weight); ?> kg</p>
                                    <a href="https://www.fitbit.com/user/<?php echo e($datos->encoded_id); ?>" target="_blank" class="btn btn-info">View Profile on Fitbit</a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>

    <script>
        var form = document.getElementById('userForm');
        form.addEventListener('submit', function(event) {
            var selectedUser = document.getElementById('selectedUser').value;
            form.action = form.action.replace('__encoded_id__', selectedUser);
            event.preventDefault();
            window.location.href = form.action;
        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <link href="<?php echo e(asset('css/fitbit_users.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u401132006/domains/fitmetrics.tech/public_html/resources/views/fitbit/fitbit_users.blade.php ENDPATH**/ ?>