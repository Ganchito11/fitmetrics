<!DOCTYPE html>
<html>
<head>
    <title>Verificación exitosa</title>
</head>
<body>
    <h1>Verificación exitosa</h1>
    <p>Tu cuenta ha sido verificada correctamente. Ahora puedes acceder al servicio CRUD.</p>
</body>
</html>

<?php /**PATH /var/www/html/crud/resources/views/verification/success.blade.php ENDPATH**/ ?>