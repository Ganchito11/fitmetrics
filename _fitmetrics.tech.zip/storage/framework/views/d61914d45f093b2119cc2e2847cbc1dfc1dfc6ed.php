<!-- _footer.blade.php -->
<footer class="footer">
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="card text-center">
                    <div class="card-header">
                        Web de Integración de Servicios Fitbit
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">TFG UNIVERSIDAD DE OVIEDO</h5>
                    </div>
                    <div class="card-footer text-muted">
                        Página elaborada por Francisco Javier de la Puente Secades
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH /home/u401132006/domains/fitmetrics.tech/public_html/resources/views/partials/_footer.blade.php ENDPATH**/ ?>