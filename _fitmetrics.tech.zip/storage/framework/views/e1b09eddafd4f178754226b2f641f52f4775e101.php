<?php $__env->startSection('title','Login'); ?>

<?php $__env->startSection('content'); ?>
<style>
    form {
        overflow: hidden;
        position: relative;
        width: 40%;
        height: 800px;
        margin: 0 auto;
    }
</style>

<form class="text-center" action="<?php echo e(route('do-login')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="exampleInputEmail1" class="form-label">Dirección de Email</label>
        <input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
        <div id="emailHelp" class="form-text">¡No compartiremos tu correo con nadie!.</div>
    </div>
    <div class="mb-3">
        <label for="exampleInputPassword1" class="form-label">Contraseña</label>
        <input type="password" name="password" class="form-control" id="exampleInputPassword1">
    </div>
    <button type="submit" class="btn btn-primary">Enviar</button>

    <!-- Aquí mostramos los mensajes de error si los hay -->
    <?php if($errors->any()): ?>
        <div class="alert alert-danger mt-3">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if(session('verification_message')): ?>
        <div class="alert alert-info">
            <?php echo e(session('verification_message')); ?>

        </div>
    <?php endif; ?>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u401132006/domains/fitmetrics.tech/resources/views/auth/login.blade.php ENDPATH**/ ?>