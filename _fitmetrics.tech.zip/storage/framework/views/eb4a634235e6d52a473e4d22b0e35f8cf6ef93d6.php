<?php $__env->startSection('title', 'Página de Inicio'); ?>

<?php $__env->startSection('content'); ?>
    <style>
        /* Estilos personalizados para el pie de página */


        footer {
            height: 10px;
            position: absolute;
            bottom: 0;
            width: 100%;
            text-align: center;
        }
    </style>

    <h1>BIENVENIDO <?php echo e(Auth::user()->name); ?></h1>


    <?php if(Auth::user()->hasRole('admin')): ?>
        <h2>Eres un admin</h2>
    <?php endif; ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/crud/resources/views/products/hello.blade.php ENDPATH**/ ?>