<?php $__env->startSection('title', 'Gestión de usuario'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Para eliminar el usuario al que está vinculado -->
    <div class="card mt-4">
        <div class="card-header text-center">
            <h4>Eliminar Usuario Vinculado</h4>
        </div>
        <div class="card-body p-4">
            <form id="userForm" method="POST" action="<?php echo e(route('user.deleteToken', ['encoded_id' => '__encoded_id__'])); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <div class="input-group mb-3">
                    <label for="selectedUser" class="input-group-text">Selecciona un Usuario para Eliminar la Relación con esta Cuenta:</label>
                    <select name="selectedUser" id="selectedUser" class="form-select">
                        <?php $__currentLoopData = $tokens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $token): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($token->userID); ?>" <?php echo e((isset($selectedUser) && $selectedUser == $token->userID) ? 'selected' : ''); ?>>
                                <?php echo e($token->userID); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <div class="input-group-append">
                        <button type="submit" class="btn btn-primary">Eliminar</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Para cambiar el valor de refresh_enabled en la tabla de tokens -->
    <div class="card mt-4">
        <div class="card-header text-center">
            <h4>Habilitar refresco automático de los Token de Acceso</h4>
        </div>
        <div class="card-body p-4">
            <form id="refreshEnabledForm" action="<?php echo e(route('user.changeTokenValue', ['id' => Auth::user()->id])); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?> 
                <label class="form-check-label mb-2" for="refreshEnabled">Cambiar el valor del refresco automático</label>
                <?php $__currentLoopData = $tokens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $token): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="refreshEnabled_<?php echo e($token->userID); ?>" name="refreshEnabled[]" value="<?php echo e($token->userID); ?>" <?php echo e($token->refresh_enabled ? 'checked' : ''); ?>>
                        <label class="form-check-label" for="refreshEnabled_<?php echo e($token->userID); ?>"><?php echo e($token->userID); ?></label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </form>
        </div>
    </div>

    <!-- Para descargar la información del usuario -->
    <div class="card mt-4">
        <div class="card-header text-center">
            <h4>Descargar toda la información almacenada en FitMetrics de mi Usuario</h4>
        </div>
        <div class="card-body p-4 text-center">
            <a href="<?php echo e(route('user.downloadInfo', ['id' => Auth::id()])); ?>" class="btn btn-info btn-block">Descargar mi información</a>
        </div>
    </div>

    <!-- Para borrar la cuenta del usuario -->
    <div class="card mt-4">
        <div class="card-header text-center">
            <h4>Eliminar Cuenta</h4>
        </div>
        <div class="card-body p-4 d-flex flex-column align-items-center">
            <form action="<?php echo e(route('user.delete', ['id' => Auth::id()])); ?>" method="POST" class="text-center" id="deleteUserForm">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger" onclick="confirmDelete(event)">Eliminar mi cuenta</button>
            </form>
        </div>
    </div>

    <script>
        function confirmDelete(event) {
            event.preventDefault();

            if (confirm('¿Estás seguro de que deseas eliminar tu cuenta? Esta acción no se puede deshacer.')) {
                var password = prompt('Por favor, ingresa tu contraseña para confirmar la eliminación de tu cuenta.');

                if (password) {
                    var form = document.getElementById('deleteUserForm');
                    var passwordInput = document.createElement('input');
                    passwordInput.setAttribute('type', 'hidden');
                    passwordInput.setAttribute('name', 'password');
                    passwordInput.setAttribute('value', password);
                    form.appendChild(passwordInput);

                    form.submit();
                }
            }
        }
    </script>



    <script>
        // Script para enviar automáticamente el formulario cuando cambia una casilla de verificación
        var refreshEnabledForm = document.getElementById('refreshEnabledForm');
        var checkboxes = document.querySelectorAll('input[name="refreshEnabled[]"]');

        checkboxes.forEach(function(checkbox) {
            checkbox.addEventListener('change', function(event) {
                refreshEnabledForm.submit();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u401132006/domains/fitmetrics.tech/resources/views/user.blade.php ENDPATH**/ ?>