<?php $__env->startSection('title', 'Página de Inicio'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Bienvenido a la página de inicio: <?php echo e(Auth::user()->name); ?></h1>
        <p>Esta es la página de inicio de tu aplicación.</p>
        
        <?php if(Auth::user()->hasRole('admin')): ?>
            <h2>Eres un admin</h2>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u401132006/domains/fitmetrics.tech/public_html/resources/views/home.blade.php ENDPATH**/ ?>